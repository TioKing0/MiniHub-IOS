#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import <CoreLocation/CoreLocation.h>
@interface ViewController : UIViewController <WKScriptMessageHandler, CLLocationManagerDelegate, NSNetServiceBrowserDelegate, NSNetServiceDelegate>
@end
