/*
 * Web MiniHub core utilities.
 * ES5 ONLY — this file runs untranspiled on Safari 9 (iOS 9).
 * No let/const, arrow functions, template literals, classes, Promise, fetch,
 * Object.assign, Array.includes, Element.closest or ES modules.
 */
(function (window, document) {
  'use strict';

  var WC = window.WC = window.WC || {};
  WC.VERSION = '0.7.0';

  var U = WC.util = {};

  U.escape = function (value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  };

  U.formatTime = function (seconds) {
    var s = Math.max(0, Math.floor(seconds || 0));
    var m = Math.floor(s / 60);
    var r = s % 60;
    return m + ':' + (r < 10 ? '0' : '') + r;
  };

  U.pad2 = function (n) {
    return (n < 10 ? '0' : '') + n;
  };

  U.extend = function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var src = arguments[i];
      if (!src) { continue; }
      for (var k in src) {
        if (Object.prototype.hasOwnProperty.call(src, k)) { target[k] = src[k]; }
      }
    }
    return target;
  };

  U.clone = function (obj) {
    return obj === null || obj === undefined ? obj : JSON.parse(JSON.stringify(obj));
  };

  U.indexOf = function (list, item) {
    for (var i = 0; i < list.length; i++) {
      if (list[i] === item) { return i; }
    }
    return -1;
  };

  U.hasClass = function (el, name) {
    if (!el || !el.className) { return false; }
    return (' ' + el.className + ' ').indexOf(' ' + name + ' ') > -1;
  };

  U.addClass = function (el, name) {
    if (!el) { return; }
    if (!U.hasClass(el, name)) { el.className = (el.className ? el.className + ' ' : '') + name; }
  };

  U.removeClass = function (el, name) {
    if (!el || !el.className) { return; }
    el.className = (' ' + el.className + ' ').replace(' ' + name + ' ', ' ').replace(/^\s+|\s+$/g, '');
  };

  U.toggleClass = function (el, name, on) {
    if (!el) { return; }
    if (on) { U.addClass(el, name); } else { U.removeClass(el, name); }
  };

  /* Element.closest replacement: walk up until an element has `attr`. */
  U.closestAttr = function (el, attr) {
    while (el && el.nodeType === 1) {
      if (el.getAttribute(attr) !== null) { return el; }
      el = el.parentNode;
    }
    return null;
  };

  U.closestClass = function (el, name) {
    while (el && el.nodeType === 1) {
      if (U.hasClass(el, name)) { return el; }
      el = el.parentNode;
    }
    return null;
  };

  U.byClass = function (name) {
    return document.getElementsByClassName(name);
  };

  U.each = function (list, fn) {
    if (!list) { return; }
    for (var i = 0; i < list.length; i++) { fn(list[i], i); }
  };

  /* ---------------------------------------------------------------------- */
  /* Storage: localStorage throws in iOS private mode, so fall back to RAM.  */

  var memory = {};
  WC.storage = {
    get: function (key, fallback) {
      var raw = null;
      try { raw = window.localStorage.getItem(key); } catch (e) { raw = memory[key] || null; }
      if (raw === null || raw === undefined) { return fallback; }
      try { return JSON.parse(raw); } catch (e2) { return fallback; }
    },
    set: function (key, value) {
      var raw = JSON.stringify(value);
      try { window.localStorage.setItem(key, raw); } catch (e) { memory[key] = raw; }
    },
    remove: function (key) {
      try { window.localStorage.removeItem(key); } catch (e) { /* ignore */ }
      delete memory[key];
    }
  };

  /* ---------------------------------------------------------------------- */
  /* Tiny event emitter.                                                     */

  function Emitter() { this._handlers = {}; }
  Emitter.prototype.on = function (name, fn) {
    (this._handlers[name] = this._handlers[name] || []).push(fn);
    return this;
  };
  Emitter.prototype.off = function (name, fn) {
    var list = this._handlers[name];
    if (!list) { return this; }
    if (!fn) { this._handlers[name] = []; return this; }
    var i = U.indexOf(list, fn);
    if (i > -1) { list.splice(i, 1); }
    return this;
  };
  Emitter.prototype.emit = function (name, data) {
    var list = (this._handlers[name] || []).slice();
    for (var i = 0; i < list.length; i++) {
      try { list[i](data); } catch (e) { if (window.WC_REPORT_ERROR) { window.WC_REPORT_ERROR('Erro em evento ' + name + ': ' + e.message); } }
    }
    return this;
  };
  WC.Emitter = Emitter;

  /* ---------------------------------------------------------------------- */
  /* XHR JSON client with a manual timeout (xhr.timeout is unreliable on    */
  /* old WebKit). callback(err, data).                                       */

  WC.http = function (method, url, body, timeoutMs, callback) {
    var done = false;
    var xhr;
    function finish(err, data) {
      if (done) { return; }
      done = true;
      callback(err, data);
    }
    try {
      xhr = new XMLHttpRequest();
      xhr.open(method, url, true);
      xhr.setRequestHeader('Accept', 'application/json');
      if (body !== null && body !== undefined) {
        xhr.setRequestHeader('Content-Type', 'application/json');
      }
      xhr.onreadystatechange = function () {
        if (xhr.readyState !== 4) { return; }
        var parsed = null;
        if (xhr.responseText) {
          try { parsed = JSON.parse(xhr.responseText); } catch (ignoreParse) { parsed = null; }
        }
        if (xhr.status >= 200 && xhr.status < 300) {
          finish(null, parsed);
        } else {
          var err = new Error(parsed && parsed.error ? parsed.error : (xhr.status ? 'HTTP ' + xhr.status : 'Sem conexão'));
          err.status = xhr.status || 0;
          err.data = parsed;
          finish(err, parsed);
        }
      };
      xhr.send(body !== null && body !== undefined ? JSON.stringify(body) : null);
    } catch (e) {
      finish(e);
      return;
    }
    setTimeout(function () {
      if (done) { return; }
      try { xhr.abort(); } catch (e) { /* ignore */ }
      finish(new Error('Tempo esgotado'));
    }, timeoutMs || 6000);
  };
})(window, document);
