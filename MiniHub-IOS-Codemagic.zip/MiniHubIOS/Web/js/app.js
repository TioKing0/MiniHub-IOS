/*
 * Web MiniHub UI. ES5 ONLY (runs untranspiled on Safari 9 / iOS 9).
 *
 * Rendering model: each screen returns an HTML string that replaces #main.
 * The player bar is built once; every second only its text/width nodes are
 * updated (classes js-*), which keeps the old A5 CPU idle.
 */
(function (window, document) {
  'use strict';

  var WC = window.WC;
  var U = WC.util;
  var esc = U.escape;

  var SETTINGS_KEY = 'webcaros.settings';
  var DEFAULT_SETTINGS = {
    theme: 'dark',
    accent: 'amber',
    skin: 'minihub',
    textSize: 'normal',
    clock24: true,
    startScreen: 'home',
    openPlayerOnPlay: false,
    homeTiles: ['music', 'files', 'gallery', 'contacts', 'devices', 'settings'],
    serviceMode: 'ios_local',
    hostAutoDetect: true,
    minihubUrl: ''
  };

  var app = WC.app = {
    settings: null,
    service: null,
    state: null,
    library: null,
    index: { tracks: {}, albums: {}, artists: {} },
    devices: null,
    files: null,
    routes: null,
    location: null,
    messages: null,
    screen: null,
    lastTrack: null,
    ui: {
      musicTab: 'queue',
      musicDetail: null,
      settingsSection: 'appearance',
      filesPath: '/',
      activeRoute: null,
      locationTimer: null,
      selectedMsg: null,
      pingResult: {}
    }
  };

  /* ---------------------------------------------------------------------- */
  /* Icons (inline SVG, 24×24, filled with currentColor).                   */

  var ICONS = {
    home: '<path d="M12 3 2 12h3v8h5v-6h4v6h5v-8h3z"/>',
    music: '<path d="M9 3v10.55A4 4 0 1 0 11 17V7h7V3z"/>',
    navigation: '<path d="M12 2 4 21l8-4 8 4z"/>',
    messages: '<path d="M3 4h18v13H8l-5 4z"/>',
    files: '<path d="M2 5h8l2 2h10v13H2z"/>',
    devices: '<path fill-rule="evenodd" d="M7 2h10v20H7zM9 4v14h6V4z"/>',
    settings: '<path d="M3 6h9v2H3zM16 6h5v2h-5zM12 4h4v6h-4zM3 16h4v2H3zM11 16h10v2H11zM7 14h4v6H7z"/>',
    play: '<path d="M7 4v16l13-8z"/>',
    pause: '<path d="M6 4h4v16H6zM14 4h4v16h-4z"/>',
    next: '<path d="M4 4v16l11-8zM16 4h3v16h-3z"/>',
    prev: '<path d="M20 4v16L9 12zM5 4h3v16H5z"/>',
    shuffle: '<path d="M10.59 9.17L5.41 4 4 5.41l5.17 5.17 1.42-1.41zM14.5 4l2.04 2.04L4 18.59 5.41 20 17.96 7.46 20 9.5V4h-5.5zm.33 9.41l-1.41 1.41 3.13 3.13L14.5 20H20v-5.5l-2.04 2.04-3.13-3.13z"/>',
    repeat: '<path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z"/>',
    repeatOne: '<path d="M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4zm-4-2V9h-1l-2 1v1h1.5v4H13z"/>',
    back: '<path d="M15.5 4 7.5 12l8 8 1.5-1.5L10.5 12 17 5.5z"/>',
    chevron: '<path d="M8.5 4 7 5.5l6.5 6.5L7 18.5 8.5 20l8-8z"/>',
    doc: '<path d="M6 2h8l5 5v15H6z"/>',
    cloud: '<path d="M7 19a5 5 0 0 1-.6-9.96A6 6 0 0 1 18 9a5 5 0 0 1 0 10z"/>',
    server: '<path d="M3 4h18v6H3zM3 14h18v6H3z"/>',
    phone: '<path fill-rule="evenodd" d="M7 2h10v20H7zM9 4v14h6V4z"/>',
    tablet: '<path fill-rule="evenodd" d="M4 3h16v18H4zM6 5v13h12V5z"/>',
    list: '<path d="M4 5h16v2H4zM4 11h16v2H4zM4 17h16v2H4z"/>',
    disc: '<path fill-rule="evenodd" d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 7a3 3 0 1 1 0 6 3 3 0 0 1 0-6z"/>',
    user: '<path d="M12 3a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9zM3 21c0-4.5 4-7 9-7s9 2.5 9 7z"/>',
    gallery: '<path d="M3 4h18v16H3zM5 6v12h14V6zM7 15l3-3 2 2 2-2 3 3v1H7zM15.5 8a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3z"/>',
    contacts: '<path d="M5 3h14v18H5zM8 3h2v2H8zM8 7h2v2H8zM8 11h2v2H8zM8 15h2v2H8zM14 7a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM10.5 17c.3-2.2 1.7-3.5 3.5-3.5s3.2 1.3 3.5 3.5z"/>',
    plus: '<path d="M11 4h2v7h7v2h-7v7h-2v-7H4v-2h7z"/>',
    minus: '<path d="M4 11h16v2H4z"/>',
    up: '<path d="M12 5l7 8h-4v6H9v-6H5z"/>',
    down: '<path d="M12 19l-7-8h4V5h6v6h4z"/>'
  };

  function icon(name, size) {
    var s = size || 28;
    return '<svg class="icon" width="' + s + '" height="' + s + '" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  }

  /* ---------------------------------------------------------------------- */
  /* Helpers                                                                 */

  function $(id) { return document.getElementById(id); }

  function trackOf(id) { return app.index.tracks[id] || null; }
  function albumOf(track) { return track ? app.index.albums[track.albumId] || null : null; }
  function artistName(id) { var a = app.index.artists[id]; return a ? a.name : ''; }

  function cover(album, size, extraClass) {
    var c = album && album.color ? album.color : ['#2a3542', '#151b23'];
    var initials = album ? album.title.split(' ').slice(0, 2).map(function (w) { return w.charAt(0); }).join('') : '';
    return '<div class="cover ' + (extraClass || '') + '" style="width:' + size + 'px;height:' + size + 'px;font-size:' + Math.round(size * 0.34) + 'px;' +
      'background-color:' + c[1] + ';background-image:-webkit-linear-gradient(135deg,' + c[0] + ',' + c[1] + ');background-image:linear-gradient(135deg,' + c[0] + ',' + c[1] + ');">' +
      esc(initials) + '</div>';
  }

  var toastTimer = null;
  function toast(msg) {
    var t = $('toast');
    t.innerHTML = esc(msg);
    U.addClass(t, 'is-visible');
    if (toastTimer) { clearTimeout(toastTimer); }
    toastTimer = setTimeout(function () { U.removeClass(t, 'is-visible'); }, 2200);
  }
  app.toast = toast;

  function reportError(err) {
    if (err) { toast((err && err.message) || 'Falha na operação'); }
  }

  function saveSettings() { WC.storage.set(SETTINGS_KEY, app.settings); }

  function applyLook() {
    var s = app.settings;
    var pack = WC.themes ? WC.themes.get(s.skin || 'original') : null;
    var isMiniHub = pack && (pack.layout === 'dashboard-grid' || pack.id === 'minihub');
    var layoutClass = pack && pack.layout === 'dashboard-grid' ? ' skin-dashboard-grid' : '';
    var skinClass = s.skin ? ' skin-' + s.skin : '';
    var screenClass = app.screen ? ' current-' + app.screen : '';
    document.body.className = 'theme-' + s.theme + ' accent-' + s.accent + (s.textSize === 'large' ? ' text-large' : '') + layoutClass + skinClass + screenClass;
    var pb = $('playerbar');
    if (pb) { pb.style.display = (app.screen === 'music' || isMiniHub) ? 'none' : ''; }
    if (WC.themes) { WC.themes.apply(s.skin || 'original'); }
  }

  /* ---------------------------------------------------------------------- */
  /* Screens                                                                 */

  var SCREENS = {};
  var RAIL = ['home', 'music', 'navigation', 'messages', 'settings'];
  var HOME_TILE_ORDER = ['music', 'files', 'gallery', 'contacts', 'navigation', 'messages', 'devices', 'settings'];
  var HOME_TILE_DEFS = {
    music: { title: 'Player', sub: 'Música e fila', icon: 'music', screen: 'music' },
    files: { title: 'Arquivos', sub: 'Servidor e fontes', icon: 'files', screen: 'files' },
    gallery: { title: 'Galeria', sub: 'Fotos e mídia', icon: 'gallery', screen: 'gallery' },
    contacts: { title: 'Contatos', sub: 'Pessoas e atalhos', icon: 'contacts', screen: 'contacts' },
    navigation: { title: 'Navegação', sub: 'Rotas e destinos', icon: 'navigation', screen: 'navigation' },
    messages: { title: 'Mensagens', sub: 'Conversas', icon: 'messages', screen: 'messages' },
    devices: { title: 'Dispositivos', sub: 'iPad, A23 e nuvem', icon: 'devices', screen: 'devices' },
    settings: { title: 'Ajustes', sub: 'Interface e conexão', icon: 'settings', screen: 'settings' }
  };

  function getHomeTiles() {
    var src = app.settings && app.settings.homeTiles;
    var out = [], seen = {}, i, id;
    if (!src || typeof src.length !== 'number') { src = DEFAULT_SETTINGS.homeTiles; }
    for (i = 0; i < src.length; i++) {
      id = String(src[i]);
      if (HOME_TILE_DEFS[id] && !seen[id]) { out.push(id); seen[id] = true; }
    }
    return out;
  }

  function homeTileStyle(index, count) {
    if (count <= 1) { return 'width:100%;height:100%;'; }
    var rows = Math.ceil(count / 2);
    var w = (count % 2 === 1 && index === count - 1) ? 100 : 50;
    var h = 100 / rows;
    return 'width:' + w + '%;height:' + h + '%;';
  }

  function renderTopActions() {
    var el = $('sb-actions');
    if (!el) { return; }
    var pack = WC.themes ? WC.themes.get(app.settings.skin || 'original') : null;
    var isMiniHub = pack && (pack.layout === 'dashboard-grid' || pack.id === 'minihub');
    if (isMiniHub) {
      var h = '';
      if (app.screen !== 'home') {
        h += '<div class="sb-action tap" data-action="go" data-arg="home" title="Início">' + icon('home', 24) + '</div>';
      }
      if (app.screen !== 'music') {
        h += '<div class="sb-action tap" data-action="go" data-arg="music" title="Música">' + icon('music', 24) + '</div>';
      }
      h += '<div class="sb-action tap" data-action="openSettings" data-arg="appearance" title="Ajustes">' + icon('settings', 24) + '</div>';
      el.innerHTML = h;
    } else {
      el.innerHTML = '<div class="sb-action tap" data-action="go" data-arg="home" title="Início">' + icon('home', 24) + '</div>' +
        '<div class="sb-action tap" data-action="openSettings" data-arg="appearance" title="Ajustes">' + icon('settings', 24) + '</div>';
    }
  }

  SCREENS.home = {
    title: 'Início',
    render: function () {
      var pack = WC.themes ? WC.themes.get(app.settings.skin || 'original') : null;
      if (pack && pack.layout === 'dashboard-grid') {
        var active = getHomeTiles();
        var mh = '<div class="mh-home"><div class="mh-hero tap" data-action="go" data-arg="music">';
        mh += '<div class="mh-hero-label">Tocando agora</div>';
        mh += '<div class="mh-cover js-cover-96">' + cover(null, 96) + '</div>';
        mh += '<div class="mh-title js-title">Boa Viagem</div><div class="mh-artist js-artist">Toque para abrir o player</div>';
        mh += '<div class="mh-progress"><div class="progress"><div class="progress-fill js-fill"></div></div><div class="mh-times"><span class="js-pos">0:00</span><span class="js-dur">0:00</span></div></div>';
        mh += '<div class="mh-controls"><div class="round-btn tap" data-action="previous">' + icon('prev', 30) + '</div>';
        mh += '<div class="round-btn round-btn-primary tap js-play" data-action="toggle">' + icon('play', 34) + '</div>';
        mh += '<div class="round-btn tap" data-action="next">' + icon('next', 30) + '</div>';
        mh += '<div class="round-btn round-btn-sm tap js-shuffle" data-action="toggleShuffle" title="Aleatório">' + icon('shuffle', 22) + '</div>';
        mh += '<div class="round-btn round-btn-sm tap js-repeat" data-action="cycleRepeat" title="Repetir">' + icon('repeat', 22) + '</div></div></div>';
        mh += '<div class="mh-tiles">';
        if (!active.length) {
          mh += '<div class="mh-empty"><div class="mh-empty-icon">' + icon('settings', 38) + '</div><div class="mh-empty-title">Home sem atalhos</div>' +
            '<div class="mh-empty-text">Abra os ajustes para escolher os botões desta tela.</div>' +
            '<div class="btn tap" data-action="openSettings" data-arg="home">Configurar Home</div></div>';
        } else {
          for (var m = 0; m < active.length; m++) {
            var def = HOME_TILE_DEFS[active[m]];
            mh += '<div class="mh-tile-wrap" style="' + homeTileStyle(m, active.length) + '"><div class="mh-tile tap" data-action="go" data-arg="' + def.screen + '">' +
              '<div class="mh-tile-icon">' + icon(def.icon, 36) + '</div><div class="mh-tile-name">' + esc(def.title) + '</div><div class="mh-tile-sub">' + esc(def.sub) + '</div></div></div>';
          }
        }
        mh += '</div></div>';
        return mh;
      }
      var now = new Date();
      var days = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
      var months = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
      var tiles = [
        ['music', 'Música', 'Biblioteca e fila'],
        ['navigation', 'Navegação', 'Rotas e mapas'],
        ['messages', 'Mensagens', 'Conversas'],
        ['files', 'Arquivos', 'MiniHub · A23'],
        ['devices', 'Dispositivos', 'Ecossistema'],
        ['settings', 'Ajustes', 'Tema · conexão']
      ];
      var h = '<div class="home">';
      h += '<div class="home-left">';
      h += '<div class="home-clock js-clock-big">' + clockText(now) + '</div>';
      h += '<div class="home-date">' + days[now.getDay()] + ', ' + now.getDate() + ' de ' + months[now.getMonth()] + '</div>';
      h += '<div class="np-card tap" data-action="go" data-arg="music">';
      h += '<div class="js-cover-96">' + cover(null, 96) + '</div>';
      h += '<div class="np-card-text"><div class="np-card-label">Tocando agora</div>';
      h += '<div class="np-card-title js-title">—</div><div class="np-card-artist js-artist"></div></div>';
      h += '<div class="np-card-progress"><div class="progress"><div class="progress-fill js-fill"></div></div></div>';
      h += '</div>';
      h += '<div class="home-actions">';
      h += '<div class="round-btn tap" data-action="previous">' + icon('prev', 30) + '</div>';
      h += '<div class="round-btn round-btn-primary tap js-play" data-action="toggle">' + icon('play', 34) + '</div>';
      h += '<div class="round-btn tap" data-action="next">' + icon('next', 30) + '</div>';
      h += '<div class="round-btn round-btn-sm tap js-shuffle" data-action="toggleShuffle" title="Aleatório">' + icon('shuffle', 22) + '</div>';
      h += '<div class="round-btn round-btn-sm tap js-repeat" data-action="cycleRepeat" title="Repetir">' + icon('repeat', 22) + '</div>';
      h += '</div>';
      h += '</div>';
      h += '<div class="tiles">';
      for (var i = 0; i < tiles.length; i++) {
        h += '<div class="tile-wrap"><div class="tile tap" data-action="go" data-arg="' + tiles[i][0] + '">' +
          '<div class="tile-icon">' + icon(tiles[i][0], 40) + '</div>' +
          '<div class="tile-name">' + tiles[i][1] + '</div><div class="tile-sub">' + tiles[i][2] + '</div></div></div>';
      }
      h += '</div></div>';
      return h;
    }
  };

  SCREENS.music = {
    title: 'Música',
    render: function () {
      var h = '<div class="music">';
      h += '<div class="np-panel">';
      h += '<div class="np-cover js-cover-200">' + cover(null, 200) + '</div>';
      h += '<div class="np-title js-title">—</div>';
      h += '<div class="np-artist js-artist-album"></div>';
      h += '<div class="seek tap" data-action="seek"><div class="progress progress-lg"><div class="progress-fill js-fill"></div></div></div>';
      h += '<div class="np-times"><span class="js-pos">0:00</span><span class="js-dur">0:00</span></div>';
      h += '<div class="np-controls">';
      h += '<div class="round-btn round-btn-lg tap" data-action="previous">' + icon('prev', 34) + '</div>';
      h += '<div class="round-btn round-btn-xl round-btn-primary tap js-play" data-action="toggle">' + icon('play', 40) + '</div>';
      h += '<div class="round-btn round-btn-lg tap" data-action="next">' + icon('next', 34) + '</div>';
      h += '</div>';
      h += '<div class="np-playback-modes">';
      h += '<div class="round-btn round-btn-sm tap js-shuffle" data-action="toggleShuffle" title="Aleatório">' + icon('shuffle', 24) + '</div>';
      h += '<div class="round-btn round-btn-sm tap js-repeat" data-action="cycleRepeat" title="Repetir">' + icon('repeat', 24) + '</div>';
      h += '</div>';
      h += '</div>';
      h += '<div class="lib-panel">';
      h += '<div class="tabs">';
      var tabs = [['queue', 'Fila'], ['albums', 'Álbuns'], ['artists', 'Artistas'], ['playlists', 'Playlists']];
      for (var i = 0; i < tabs.length; i++) {
        h += '<div class="tab tap' + (app.ui.musicTab === tabs[i][0] ? ' is-active' : '') + '" data-action="musicTab" data-arg="' + tabs[i][0] + '">' + tabs[i][1] + '</div>';
      }
      h += '</div>';
      h += '<div class="lib-list scroll" id="lib-list">' + renderLibraryList() + '</div>';
      h += '</div></div>';
      return h;
    }
  };

  function trackRow(track, contextIds, numberLabel) {
    var current = app.state && app.state.currentTrack === track.id;
    return '<div class="list-row tap' + (current ? ' is-current' : '') + '" data-action="playTrack" data-arg="' + track.id + '" data-context="' + esc(contextIds.join(',')) + '">' +
      '<div class="row-num">' + (current ? icon(app.state.playing ? 'music' : 'pause', 20) : esc(numberLabel)) + '</div>' +
      '<div class="row-main"><div class="row-title">' + esc(track.title) + '</div><div class="row-sub">' + esc(artistName(track.artistId)) + '</div></div>' +
      '<div class="row-meta">' + U.formatTime(track.duration) + '</div></div>';
  }

  function navRow(action, arg, coverHtml, title, sub) {
    return '<div class="list-row tap" data-action="' + action + '" data-arg="' + esc(arg) + '">' +
      '<div class="row-cover">' + coverHtml + '</div>' +
      '<div class="row-main"><div class="row-title">' + esc(title) + '</div><div class="row-sub">' + esc(sub) + '</div></div>' +
      '<div class="row-meta">' + icon('chevron', 22) + '</div></div>';
  }

  function backRow(label) {
    return '<div class="list-row list-back tap" data-action="musicBack">' + icon('back', 24) + '<span>' + esc(label) + '</span></div>';
  }

  function renderLibraryList() {
    var lib = app.library;
    if (!lib) { return '<div class="empty">Biblioteca indisponível nesta conexão.</div>'; }
    var tab = app.ui.musicTab;
    var detail = app.ui.musicDetail;
    var h = '';
    var i, ids, list;

    if (detail) {
      if (detail.type === 'album') {
        var album = app.index.albums[detail.id];
        list = lib.tracks.filter(function (t) { return t.albumId === detail.id; });
        h += backRow('Álbuns');
        h += '<div class="detail-head">' + cover(album, 72) + '<div><div class="detail-title">' + esc(album.title) + '</div><div class="row-sub">' + esc(artistName(album.artistId)) + ' · ' + album.year + '</div></div></div>';
      } else if (detail.type === 'artist') {
        list = lib.tracks.filter(function (t) { return t.artistId === detail.id; });
        h += backRow('Artistas');
        h += '<div class="detail-head"><div class="avatar">' + icon('user', 36) + '</div><div><div class="detail-title">' + esc(artistName(detail.id)) + '</div><div class="row-sub">' + list.length + ' músicas</div></div></div>';
      } else {
        var pl = null;
        for (i = 0; i < lib.playlists.length; i++) { if (lib.playlists[i].id === detail.id) { pl = lib.playlists[i]; } }
        list = pl ? pl.trackIds.map(trackOf).filter(Boolean) : [];
        h += backRow('Playlists');
        h += '<div class="detail-head"><div class="avatar">' + icon('list', 36) + '</div><div><div class="detail-title">' + esc(pl ? pl.name : '') + '</div><div class="row-sub">' + list.length + ' músicas</div></div></div>';
      }
      ids = list.map(function (t) { return t.id; });
      for (i = 0; i < list.length; i++) { h += trackRow(list[i], ids, i + 1); }
      return h;
    }

    if (tab === 'queue') {
      ids = app.state ? app.state.queue : [];
      if (!ids.length) { return '<div class="empty">A fila está vazia.</div>'; }
      for (i = 0; i < ids.length; i++) {
        var t = trackOf(ids[i]);
        if (t) { h += trackRow(t, ids, i + 1); }
      }
      return h;
    }
    if (tab === 'albums') {
      for (i = 0; i < lib.albums.length; i++) {
        var a = lib.albums[i];
        h += navRow('openAlbum', a.id, cover(a, 52), a.title, artistName(a.artistId) + ' · ' + a.year);
      }
      return h;
    }
    if (tab === 'artists') {
      for (i = 0; i < lib.artists.length; i++) {
        var ar = lib.artists[i];
        h += navRow('openArtist', ar.id, '<div class="avatar avatar-sm">' + icon('user', 26) + '</div>', ar.name, 'Artista');
      }
      return h;
    }
    for (i = 0; i < lib.playlists.length; i++) {
      var p = lib.playlists[i];
      h += navRow('openPlaylist', p.id, '<div class="avatar avatar-sm">' + icon('list', 26) + '</div>', p.name, p.trackIds.length + ' músicas');
    }
    return h;
  }

  function refreshLibraryList() {
    var el = $('lib-list');
    if (el) { el.innerHTML = renderLibraryList(); }
  }

  function compassLabel(value) {
    var deg = Number(value);
    if (isNaN(deg)) { return '—'; }
    deg = ((deg % 360) + 360) % 360;
    var labels = ['N', 'NE', 'L', 'SE', 'S', 'SO', 'O', 'NO'];
    return labels[Math.round(deg / 45) % 8] + ' · ' + Math.round(deg) + '°';
  }

  function locationAgeText(timestampMs) {
    var ts = Number(timestampMs || 0);
    if (!ts) { return 'sem posição'; }
    var age = Math.max(0, Math.round((new Date().getTime() - ts) / 1000));
    if (age < 3) { return 'agora'; }
    if (age < 60) { return 'há ' + age + ' s'; }
    return 'há ' + Math.round(age / 60) + ' min';
  }

  function drawNavigationCanvas() {
    var canvas = $('nav-canvas');
    if (!canvas) { return; }
    var parent = canvas.parentElement;
    var w = parent ? parent.clientWidth : 640;
    var h = parent ? parent.clientHeight : 480;
    if (w < 80 || h < 80) { w = 640; h = 480; }
    canvas.width = w;
    canvas.height = h;

    var ctx = canvas.getContext('2d');
    if (!ctx) { return; }

    var loc = app.location || {};
    var nav = app.navigationState || {};
    var lat = Number(loc.latitude);
    var lng = Number(loc.longitude);
    var hasFix = !!loc.hasFix && !isNaN(lat) && !isNaN(lng);
    var bearing = Number(loc.bearingDegrees);
    if (isNaN(bearing)) { bearing = 0; }
    var speedKmh = Math.max(0, Number(loc.speedMps || 0) * 3.6);

    ctx.fillStyle = '#070b10';
    ctx.fillRect(0, 0, w, h);

    var cx = Math.round(w * 0.50);
    var cy = Math.round(h * 0.54);
    var radius = Math.max(86, Math.min(w * 0.43, h * 0.43));

    /* Old-iOS friendly circular HUD: map content is clipped to one simple circle. */
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.clip();
    ctx.fillStyle = '#091018';
    ctx.fillRect(cx - radius, cy - radius, radius * 2, radius * 2);

    if (hasFix) {
      var latMeters = 110540;
      var lngMeters = 111320 * Math.cos(lat * Math.PI / 180);
      var metersPerPixel = speedKmh > 75 ? 4.4 : (speedKmh > 35 ? 3.2 : (speedKmh > 8 ? 2.4 : 1.8));
      var rotation = -bearing * Math.PI / 180;
      var cosR = Math.cos(rotation);
      var sinR = Math.sin(rotation);

      function project(pointLat, pointLng) {
        var east = (Number(pointLng) - lng) * lngMeters;
        var north = (Number(pointLat) - lat) * latMeters;
        var rx = east * cosR - (-north) * sinR;
        var ry = east * sinR + (-north) * cosR;
        return { x: cx + rx / metersPerPixel, y: cy + ry / metersPerPixel };
      }

      /* Real nearby OSM geometry from Android. No synthetic street grid. */
      var roads = nav.roads || [];
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (var r = 0; r < roads.length; r++) {
        var road = roads[r] || {};
        var points = road.points || [];
        if (points.length < 2) { continue; }
        var major = road.highway === 'motorway' || road.highway === 'trunk' || road.highway === 'primary';
        var medium = road.highway === 'secondary' || road.highway === 'tertiary';
        ctx.strokeStyle = major ? 'rgba(224,238,247,0.90)' : (medium ? 'rgba(162,199,222,0.78)' : 'rgba(104,153,184,0.62)');
        ctx.lineWidth = major ? 3.4 : (medium ? 2.5 : 1.7);
        ctx.beginPath();
        for (var rp = 0; rp < points.length; rp++) {
          var roadPoint = project(points[rp].lat, points[rp].lng);
          if (rp === 0) { ctx.moveTo(roadPoint.x, roadPoint.y); }
          else { ctx.lineTo(roadPoint.x, roadPoint.y); }
        }
        ctx.stroke();
      }

      /* Recent trajectory is the only fallback geometry when road data is unavailable. */
      var crumbs = nav.breadcrumbs || [];
      if (crumbs.length > 1) {
        ctx.strokeStyle = roads.length ? 'rgba(114,236,178,0.42)' : 'rgba(220,239,250,0.84)';
        ctx.lineWidth = roads.length ? 2.2 : 3.2;
        ctx.beginPath();
        for (var i = Math.max(0, crumbs.length - 80); i < crumbs.length; i++) {
          var crumb = project(crumbs[i].lat, crumbs[i].lng);
          if (i === Math.max(0, crumbs.length - 80)) { ctx.moveTo(crumb.x, crumb.y); }
          else { ctx.lineTo(crumb.x, crumb.y); }
        }
        ctx.stroke();
      }
    }

    /* Vehicle stays fixed and points upward; map rotates underneath it (heading-up). */
    ctx.save();
    ctx.translate(cx, cy);
    ctx.beginPath();
    ctx.moveTo(0, -16);
    ctx.lineTo(10, 11);
    ctx.lineTo(0, 6);
    ctx.lineTo(-10, 11);
    ctx.closePath();
    ctx.fillStyle = hasFix ? '#6ee7a8' : '#64748b';
    ctx.fill();
    ctx.strokeStyle = '#071017';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();

    ctx.restore();

    /* Bright outer ring matches the intentionally tiny, glanceable navigation HUD. */
    ctx.strokeStyle = '#e8f2f7';
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.stroke();

    /* Tiny north marker; avoids labels and keeps the display useful at a glance. */
    var northAngle = (-bearing - 90) * Math.PI / 180;
    var nx = cx + Math.cos(northAngle) * (radius + 10);
    var ny = cy + Math.sin(northAngle) * (radius + 10);
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.moveTo(nx, ny - 7);
    ctx.lineTo(nx + 6, ny + 5);
    ctx.lineTo(nx - 6, ny + 5);
    ctx.closePath();
    ctx.fill();
  }

  function pollNavigationLocation() {
    if (!app.service || !app.service.getLocation) { return; }
    app.service.getLocation(function (err, data) {
      if (err) {
        app.location = { supported: true, tracking: false, hasFix: false, lastError: err.message || 'GPS indisponível' };
      } else {
        app.location = data || { supported: false, tracking: false, hasFix: false };
      }
      if (app.service.getNavigationState) {
        app.service.getNavigationState(function (navErr, navData) {
          if (!navErr && navData) {
            app.navigationState = navData;
          }
          if (app.screen === 'navigation') {
            renderScreen();
            drawNavigationCanvas();
          }
        });
      } else {
        if (app.screen === 'navigation') {
          renderScreen();
          drawNavigationCanvas();
        }
      }
    });
  }

  function startNavigationLocationPolling() {
    if (app.ui.locationTimer) { clearInterval(app.ui.locationTimer); app.ui.locationTimer = null; }
    if (!app.service) { return; }
    if (app.service.setLocationMode) {
      app.service.setLocationMode('NAVIGATION', function () {});
    }
    pollNavigationLocation();
    app.ui.locationTimer = setInterval(function () {
      if (app.screen === 'navigation') { pollNavigationLocation(); }
    }, 1000);
  }

  SCREENS.navigation = {
    title: 'Navegação',
    render: function () {
      var r = app.routes;
      var loc = app.location || {};
      var nav = app.navigationState || {};
      var activeRoute = app.ui.activeRoute;
      var h = '<div class="split">';

      h += '<div class="nav-canvas-container">';
      h += '<div class="nav-canvas-wrapper"><canvas id="nav-canvas" class="nav-canvas"></canvas></div>';

      if (nav.hasNotification || nav.active || activeRoute) {
        var maneuver = nav.maneuver || nav.maneuverType || 'UNKNOWN';
        var iconName = (maneuver === 'LEFT' || maneuver === 'TURN_LEFT' || maneuver === 'SLIGHT_LEFT' || maneuver === 'TURN_SLIGHT_LEFT' || maneuver === 'TURN_SHARP_LEFT' || maneuver === 'KEEP_LEFT') ? 'prev' :
                       (maneuver === 'RIGHT' || maneuver === 'TURN_RIGHT' || maneuver === 'SLIGHT_RIGHT' || maneuver === 'TURN_SLIGHT_RIGHT' || maneuver === 'TURN_SHARP_RIGHT' || maneuver === 'KEEP_RIGHT') ? 'next' :
                       (maneuver === 'UTURN' || maneuver === 'U_TURN') ? 'back' : 'navigation';
        var instruction = nav.instruction || nav.maneuverInstruction || nav.title || (activeRoute ? activeRoute.destination : 'Em navegação');
        var subText = nav.roadName || nav.text || (activeRoute ? activeRoute.address : '');
        var dist = nav.distanceText || (nav.distanceMeters !== undefined && nav.distanceMeters !== null ? Math.round(Number(nav.distanceMeters)) + ' m' : '') || (activeRoute ? activeRoute.distance : '');
        var eta = nav.eta || nav.etaText || (activeRoute ? activeRoute.eta : '');
        var appName = nav.sourceApp || 'MiniHub';

        h += '<div class="nav-hud-overlay"><div class="nav-maneuver-card">';
        h += '<div class="nav-maneuver-icon">' + icon(iconName, 44) + '</div>';
        h += '<div class="nav-maneuver-details">';
        h += '<div class="nav-maneuver-instruction">' + esc(instruction) + '</div>';
        if (subText) { h += '<div class="nav-maneuver-sub">' + esc(subText) + '</div>'; }
        if (dist || eta) {
          h += '<div class="nav-maneuver-metrics">';
          if (dist) { h += '<span>' + esc(dist) + '</span>'; }
          if (eta) { h += '<span>ETA ' + esc(eta) + '</span>'; }
          h += '<span>' + esc(appName) + '</span>';
          h += '</div>';
        }
        h += '</div></div></div>';
      }

      var speedKmh = Math.max(0, Number(loc.speedMps || 0) * 3.6);
      var bearingText = compassLabel(loc.bearingDegrees);
      h += '<div class="nav-bottom-stats">';
      h += '<div class="nav-stat-pill"><strong>' + Math.round(speedKmh) + '</strong> km/h · ' + esc(bearingText) + '</div>';
      h += '<div class="nav-stat-pill">' + (loc.hasFix ? ('GPS ±' + Math.round(loc.accuracyMeters || 0) + 'm') : 'Aguardando GPS') + '</div>';
      h += '</div>';

      h += '</div>'; // end nav-canvas-container

      h += '<div class="side-panel scroll">' +
        '<div class="panel-title">GPS do Galaxy A23</div>' +
        '<div class="location-status-card">' +
          '<div class="status-line"><span>Conexão</span><strong>' + (loc.tracking ? 'Ativa' : loc.requested ? 'Solicitada' : 'Parada') + '</strong></div>' +
          '<div class="status-line"><span>Permissão</span><strong>' + (loc.permissionGranted ? 'Concedida' : 'Necessária') + '</strong></div>' +
          '<div class="status-line"><span>GPS</span><strong>' + (loc.locationEnabled ? 'Ligado' : 'Desligado') + '</strong></div>' +
          '<div class="status-line"><span>Posição</span><strong>' + (loc.hasFix ? locationAgeText(loc.timestampMs) : 'Aguardando') + '</strong></div>' +
        '</div>' +
        '<div class="location-actions">' +
          '<div class="btn tap" data-action="startLocation">Ativar / reconectar GPS</div>' +
          '<div class="btn btn-ghost tap" data-action="refreshLocation">Atualizar posição</div>' +
          (loc.requested ? '<div class="btn btn-ghost tap" data-action="stopLocation">Desativar GPS</div>' : '') +
        '</div>' +
        '<div class="panel-title location-dest-title">Destinos Frequentes</div>';
      if (!r || !r.length) {
        h += '<div class="empty">Rotas serão conectadas em uma etapa posterior. O GPS ao vivo já vem do A23.</div>';
      } else {
        for (var i = 0; i < r.length; i++) {
          var route = r[i];
          var isCurrent = activeRoute && activeRoute.id === route.id;
          h += '<div class="list-row tap' + (isCurrent ? ' is-selected' : '') + '" data-action="selectRoute" data-arg="' + esc(route.id) + '">' +
            icon('navigation', 26) +
            '<div class="row-main"><div class="row-title">' + esc(route.destination) + '</div>' +
            '<div class="row-sub">' + esc(route.address) + '</div></div>' +
            '<div class="row-meta"><span class="route-eta">' + esc(route.eta) + '</span><span class="route-dist">' + esc(route.distance) + '</span></div></div>';
        }
      }
      h += '<div class="note">A posição desta tela vem do GPS do MiniHub Android. Ruas reais são simplificadas no Android e desenhadas localmente. Sem internet, o HUD mantém GPS, direção e trajetória recente.</div>' +
        '</div></div>';
      return h;
    },
    load: function () {
      app.service.getRoutes(function (err, list) {
        app.routes = err ? [] : list;
        if (app.screen === 'navigation') { renderScreen(); }
      });
      startNavigationLocationPolling();
    }
  };

  SCREENS.messages = {
    title: 'Mensagens',
    render: function () {
      var msgs = app.messages || [];
      var sel = app.ui.selectedMsg || (msgs.length ? msgs[0] : null);
      var h = '<div class="split"><div class="side-panel side-panel-left scroll">';
      h += '<div class="panel-title">Conversas Recentes</div>';
      if (!msgs.length) {
        h += '<div class="empty">Nenhuma mensagem recente.</div>';
      } else {
        for (var i = 0; i < msgs.length; i++) {
          var m = msgs[i];
          var isSel = sel && sel.id === m.id;
          h += '<div class="list-row tap' + (isSel ? ' is-selected' : '') + '" data-action="selectMessage" data-arg="' + esc(m.id) + '">' +
            '<div class="avatar avatar-sm">' + icon(m.channel === 'WhatsApp' ? 'messages' : m.channel === 'SMS' ? 'phone' : 'list', 24) + '</div>' +
            '<div class="row-main"><div class="row-title">' + esc(m.sender) + (m.unread ? ' <span class="dot-unread"></span>' : '') + '</div>' +
            '<div class="row-sub">' + esc(m.text) + '</div></div>' +
            '<div class="row-meta">' + esc(m.time) + '</div></div>';
        }
      }
      h += '</div><div class="info-panel">';
      if (sel) {
        h += '<div class="msg-reader">' +
          '<div class="msg-header">' +
          '<div class="avatar">' + icon('user', 36) + '</div>' +
          '<div><div class="msg-sender">' + esc(sel.sender) + '</div>' +
          '<div class="msg-channel">' + esc(sel.channel) + ' · ' + esc(sel.time) + '</div></div>' +
          '</div>' +
          '<div class="msg-body">' + esc(sel.text) + '</div>' +
          '<div class="msg-quick-replies">' +
          '<div class="msg-qr-label">Respostas Rápidas Seguras:</div>' +
          '<div class="btn tap" data-action="quickReply" data-arg="A caminho!">"A caminho!"</div>' +
          '<div class="btn tap" data-action="quickReply" data-arg="Chego em 10 minutos.">"Chego em 10 min."</div>' +
          '<div class="btn tap" data-action="quickReply" data-arg="Estou no trânsito, já respondo.">"No trânsito."</div>' +
          '</div>' +
          '</div>';
      } else {
        h += '<div class="empty">Selecione uma mensagem para ler.</div>';
      }
      h += '</div></div>';
      return h;
    },
    load: function () {
      app.service.getMessages(function (err, list) {
        app.messages = err ? [] : list;
        if (app.screen === 'messages') { renderScreen(); }
      });
    }
  };

  SCREENS.files = {
    title: 'Arquivos',
    render: function () {
      var path = app.ui.filesPath;
      var h = '<div class="files">';
      h += '<div class="files-head">';
      if (path !== '/') { h += '<div class="btn tap" data-action="filesUp">' + icon('back', 24) + '<span>Voltar</span></div>'; }
      h += '<div class="files-path">' + esc(path === '/' ? 'Fontes de armazenamento' : path) + '</div></div>';
      h += '<div class="files-list scroll" id="files-list">' + renderFiles() + '</div>';
      h += '</div>';
      return h;
    },
    load: function () {
      app.files = null;
      app.service.getFiles(app.ui.filesPath, function (err, data) {
        app.files = err ? { error: err.message } : data;
        var el = $('files-list');
        if (el) { el.innerHTML = renderFiles(); }
      });
    }
  };

  function renderFiles() {
    var f = app.files;
    if (!f) { return '<div class="empty">Carregando…</div>'; }
    if (f.error) { return '<div class="empty">Não foi possível listar: ' + esc(f.error) + '</div>'; }
    if (!f.items.length) { return '<div class="empty">Pasta vazia.</div>'; }
    var h = '';
    for (var i = 0; i < f.items.length; i++) {
      var it = f.items[i];
      var ic = it.type === 'source' ? 'server' : it.type === 'folder' ? 'files' : it.type === 'audio' ? 'music' : 'doc';
      if (it.type === 'source' && it.path === '/a23') { ic = 'phone'; }
      var action = it.type === 'audio' ? 'playFile' : (it.path ? 'openPath' : 'soon');
      var arg = it.type === 'audio' ? it.trackId : (it.path || '');
      h += '<div class="list-row tap" data-action="' + action + '" data-arg="' + esc(arg) + '">' +
        '<div class="row-icon">' + icon(ic, 28) + '</div>' +
        '<div class="row-main"><div class="row-title">' + esc(it.name) + '</div><div class="row-sub">' +
        esc(it.type === 'source' ? 'Fonte' : it.type === 'folder' ? 'Pasta' : it.type === 'audio' ? 'Áudio · ' + it.size : 'Documento · ' + it.size) +
        '</div></div>' +
        '<div class="row-meta">' + (it.path ? icon('chevron', 22) : it.type === 'audio' ? icon('play', 22) : '') + '</div></div>';
    }
    return h;
  }

  SCREENS.gallery = {
    title: 'Galeria',
    render: function () {
      return '<div class="module-hub"><div class="module-hero">' +
        '<div class="module-icon">' + icon('gallery', 54) + '</div><div class="module-title">Galeria</div>' +
        '<div class="module-text">A galeria permanece local: as futuras fotos virão do MiniHub Android, sem backend cloud. Até a fonte real estar conectada, use Arquivos.</div>' +
        '<div class="btn tap" data-action="go" data-arg="files">Abrir Arquivos</div></div>' +
        '<div class="module-cards"><div class="module-card"><div class="module-card-icon">' + icon('server', 30) + '</div><div class="module-card-title">Servidor</div><div class="module-card-sub">Fonte preparada</div></div>' +
        '<div class="module-card"><div class="module-card-icon">' + icon('phone', 30) + '</div><div class="module-card-title">Galaxy A23</div><div class="module-card-sub">Via MiniHub</div></div></div></div>';
    }
  };

  SCREENS.contacts = {
    title: 'Contatos',
    render: function () {
      return '<div class="module-hub"><div class="module-hero">' +
        '<div class="module-icon">' + icon('contacts', 54) + '</div><div class="module-title">Contatos</div>' +
        '<div class="module-text">Este módulo já faz parte da navegação do Web MiniHub e está preparado para receber contatos do MiniHub. Nenhum contato fictício é exibido enquanto uma fonte real não estiver conectada.</div>' +
        '<div class="btn tap" data-action="go" data-arg="devices">Ver dispositivos</div></div>' +
        '<div class="module-cards"><div class="module-card"><div class="module-card-icon">' + icon('phone', 30) + '</div><div class="module-card-title">Galaxy A23</div><div class="module-card-sub">Fonte planejada</div></div>' +
        '<div class="module-card"><div class="module-card-icon">' + icon('messages', 30) + '</div><div class="module-card-title">Mensagens</div><div class="module-card-sub">Atalhos futuros</div></div></div></div>';
    }
  };

  SCREENS.devices = {
    title: 'Dispositivos',
    render: function () {
      var h = '<div class="devices">';
      var d = app.devices;
      if (!d) { return h + '<div class="empty">Carregando…</div></div>'; }
      if (d.error) { return h + '<div class="empty">Não foi possível listar: ' + esc(d.error) + '</div></div>'; }
      var labels = { online: 'Conectado', offline: 'Desconectado', planned: 'Planejado' };
      for (var i = 0; i < d.length; i++) {
        var dev = d[i];
        h += '<div class="device-wrap"><div class="device status-' + esc(dev.status) + '">' +
          '<div class="device-icon">' + icon(dev.kind, 44) + '</div>' +
          '<div class="device-name">' + esc(dev.name) + '</div>' +
          '<div class="device-role">' + esc(dev.role) + '</div>' +
          '<div class="device-detail">' + esc(dev.detail) + '</div>' +
          '<div class="device-status"><span class="dot"></span>' + (labels[dev.status] || esc(dev.status)) + '</div>' +
          '</div></div>';
      }
      h += '</div>';
      return h;
    },
    load: function () {
      app.service.getDevices(function (err, list) {
        app.devices = err ? { error: err.message } : list;
        if (app.screen === 'devices') { renderScreen(); }
      });
    }
  };

  SCREENS.settings = {
    title: 'Ajustes',
    render: function () {
      var sections = [
        ['appearance', 'Aparência'],
        ['home', 'Home e atalhos'],
        ['player', 'Player'],
        ['connection', 'Conexão e servidor'],
        ['interface', 'Interface'],
        ['system', 'Sistema']
      ];
      var h = '<div class="settings"><div class="settings-nav">';
      for (var i = 0; i < sections.length; i++) {
        h += '<div class="list-row tap' + (app.ui.settingsSection === sections[i][0] ? ' is-selected' : '') + '" data-action="settingsSection" data-arg="' + sections[i][0] + '">' +
          '<div class="row-main"><div class="row-title">' + sections[i][1] + '</div></div><div class="row-meta">' + icon('chevron', 22) + '</div></div>';
      }
      h += '</div><div class="settings-pane scroll">' + renderSettingsPane() + '</div></div>';
      return h;
    }
  };

  function seg(key, options) {
    var h = '<div class="seg">';
    for (var i = 0; i < options.length; i++) {
      var on = String(app.settings[key]) === String(options[i][0]);
      h += '<div class="seg-btn tap' + (on ? ' is-active' : '') + '" data-action="set" data-arg="' + key + '" data-value="' + esc(options[i][0]) + '">' + esc(options[i][1]) + '</div>';
    }
    return h + '</div>';
  }

  function field(label, help, control) {
    return '<div class="field"><div class="field-label">' + label + '</div>' + (help ? '<div class="field-help">' + help + '</div>' : '') + control + '</div>';
  }

  function urlField(key, label, placeholder, kind) {
    var ping = app.ui.pingResult[kind];
    return field(label, null,
      '<div class="url-row"><input class="input" id="input-' + key + '" type="url" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="' + placeholder + '" value="' + esc(app.settings[key]) + '">' +
      '<div class="btn tap" data-action="saveUrl" data-arg="' + key + '">Salvar</div>' +
      '<div class="btn tap" data-action="testUrl" data-arg="' + kind + '">Testar</div></div>' +
      (ping ? '<div class="field-help ' + (ping.ok ? 'text-ok' : 'text-bad') + '">' + esc(ping.text) + '</div>' : ''));
  }

  function cacheAgeText(savedAt) {
    var t = Number(savedAt || 0);
    if (!t) { return 'nenhum cache salvo'; }
    var sec = Math.max(0, Math.round((new Date().getTime() - t) / 1000));
    if (sec < 60) { return 'agora'; }
    if (sec < 3600) { return Math.floor(sec / 60) + ' min atrás'; }
    if (sec < 86400) { return Math.floor(sec / 3600) + ' h atrás'; }
    return Math.floor(sec / 86400) + ' d atrás';
  }

  function renderSettingsPane() {
    var s = app.ui.settingsSection;
    if (s === 'appearance') {
      var packs = WC.themes ? WC.themes.all() : {};
      var opts = [], id;
      for (id in packs) { if (packs.hasOwnProperty(id)) { opts.push([id, packs[id].name]); } }
      var current = WC.themes ? WC.themes.get(app.settings.skin || 'original') : null;
      var customInfo = current && WC.themes.isCustom(current.id)
        ? '<div class="btn btn-danger tap" data-action="removeSkin" data-arg="' + esc(current.id) + '">Excluir skin atual</div>' : '';
      var uploader = '<label class="btn theme-upload">Importar skin (.json)<input id="theme-file" type="file" accept="application/json,.json"></label>' +
        '<div class="field-help">Skins são pacotes JSON de até 32 KB e ficam salvas neste navegador. O arquivo não executa CSS nem JavaScript.</div>' + customInfo;
      return field('Skin', 'Troque toda a identidade visual sem alterar a estrutura do Web MiniHub.', seg('skin', opts)) +
        field('Importar skin', 'Funciona também pelo seletor de arquivos do navegador móvel.', uploader) +
        field('Compatibilidade', 'Tema e cor antigos continuam disponíveis como fallback.', seg('theme', [['dark', 'Escuro'], ['black', 'Preto']])) +
        field('Destaque legado', null, seg('accent', [['amber', 'Âmbar'], ['cyan', 'Ciano'], ['green', 'Verde']]));
    }
    if (s === 'home') {
      var activeTiles = getHomeTiles();
      var activeMap = {}, i, id, def, rows = '';
      for (i = 0; i < activeTiles.length; i++) { activeMap[activeTiles[i]] = true; }
      for (i = 0; i < HOME_TILE_ORDER.length; i++) {
        id = HOME_TILE_ORDER[i]; def = HOME_TILE_DEFS[id];
        rows += '<div class="home-config-row"><div class="home-config-icon">' + icon(def.icon, 26) + '</div>' +
          '<div class="home-config-main"><div class="home-config-title">' + esc(def.title) + '</div><div class="home-config-sub">' + esc(def.sub) + '</div></div>';
        if (activeMap[id]) {
          rows += '<div class="home-config-actions"><div class="mini-btn tap" data-action="homeMove" data-arg="' + id + '" data-value="up">' + icon('up', 18) + '</div>' +
            '<div class="mini-btn tap" data-action="homeMove" data-arg="' + id + '" data-value="down">' + icon('down', 18) + '</div>' +
            '<div class="mini-btn mini-btn-danger tap" data-action="homeToggle" data-arg="' + id + '">' + icon('minus', 18) + '</div></div>';
        } else {
          rows += '<div class="home-config-actions"><div class="mini-btn mini-btn-add tap" data-action="homeToggle" data-arg="' + id + '">' + icon('plus', 18) + '</div></div>';
        }
        rows += '</div>';
      }
      return field('Atalhos da Home', 'Adicione, remova e reorganize os botões. O layout se redimensiona sozinho de 0 a 8 atalhos.', '<div class="home-config">' + rows + '</div>') +
        field('Organização automática', '1 botão ocupa todo o painel; 2 ficam lado a lado; quantidades ímpares dão largura total ao último botão. De 4 a 8 atalhos o painel cria novas linhas automaticamente.', '<div class="btn-row"><div class="btn tap" data-action="resetHome">Restaurar atalhos padrão</div><div class="btn tap" data-action="go" data-arg="home">Visualizar Home</div></div>');
    }
    if (s === 'player') {
      return field('Ao escolher uma música', null, seg('openPlayerOnPlay', [['false', 'Permanecer'], ['true', 'Abrir Música']])) +
        field('Controles no iPad', 'O Safari controla reprodução, aleatório e repetição. O volume físico continua sob controle do iPad.', '<div class="note">Previous · Play/Pause · Next · Shuffle · Repeat</div>');
    }
    if (s === 'connection') {
      var info = app.service.getInfo();
      var miniHelp = 'MiniHub · iPad usa a biblioteca real do Galaxy A23, mas mantém a reprodução no elemento de áudio deste iPad.';
      if (window.location.protocol === 'https:') {
        miniHelp += ' Esta página está em HTTPS: um MiniHub local em http:// será bloqueado pelo navegador. Para LAN, sirva esta build pelo próprio MiniHub/A23 (mesma origem).';
      } else {
        miniHelp += ' Deixe o endereço vazio quando esta build estiver sendo servida pelo próprio MiniHub.';
      }
      var extra = '';
      if (info.id === 'minihub-media') {
        extra = field('Biblioteca MiniHub', miniHelp,
          '<div class="status-line">' + (info.libraryCount || 0) + ' faixas · ' + (info.cached ? 'cache local (' + esc(cacheAgeText(info.cacheSavedAt)) + ')' : (info.connected ? 'fonte ao vivo' : 'aguardando servidor')) + '</div>' +
          '<div class="btn-row"><div class="btn tap" data-action="refreshLibrary">Atualizar biblioteca</div><div class="btn tap" data-action="clearLibraryCache">Limpar cache</div></div>');
      } else {
        extra = field('MiniHub · áudio no iPad', miniHelp, '<div class="field-help">Selecione “MiniHub · iPad” acima para usar este modo.</div>');
      }
      return field('Fonte de dados', 'Sem Android conectado, o MiniHub usa somente músicas reais da pasta local do iPad.',
          seg('serviceMode', [['ios_local', 'Local · iPad'], ['minihub_media', 'MiniHub · Android'], ['minihub', 'Controle Host']])) +
        field('Status', null, '<div class="status-line"><span class="dot ' + (info.connected ? 'dot-ok' : 'dot-bad') + '"></span>' + esc(info.label) + (info.connected ? ' · conectado' : ' · sem conexão') + '</div>') +
        extra +
        urlField('minihubUrl', 'MiniHub (Galaxy A23)', 'vazio = mesma origem · ou http://192.168.0.10:8080', 'minihub');
    }
    if (s === 'interface') {
      return field('Tamanho do texto', null, seg('textSize', [['normal', 'Normal'], ['large', 'Grande']])) +
        field('Relógio', null, seg('clock24', [['true', '24 horas'], ['false', '12 horas']])) +
        field('Tela inicial', null, seg('startScreen', [['home', 'Início'], ['music', 'Música']]));
    }
    return field('Versão', null, '<div class="status-line">Web MiniHub ' + WC.VERSION + '</div>') +
      field('Navegador', null, '<div class="field-help">' + esc(navigator.userAgent) + '</div>') +
      field('Tela', null, '<div class="status-line">' + window.innerWidth + ' × ' + window.innerHeight + (navigator.standalone ? ' · tela cheia' : ' · Safari') + '</div>') +
      field('Ferramentas', null,
        '<div class="btn-row"><a class="btn" href="/diag.html">Diagnóstico</a>' +
        '<div class="btn tap" data-action="reload">Recarregar</div>' +
        '<div class="btn btn-danger tap" data-action="resetAll">Restaurar padrões</div></div>');
  }

  /* ---------------------------------------------------------------------- */
  /* Shell: rail, player bar, clock                                          */

  function renderRail() {
    var h = '';
    for (var i = 0; i < RAIL.length; i++) {
      h += '<div class="rail-btn tap" id="rail-' + RAIL[i] + '" data-action="go" data-arg="' + RAIL[i] + '">' +
        '<div class="rail-icon">' + icon(RAIL[i], 30) + '</div><div class="rail-label">' + SCREENS[RAIL[i]].title + '</div></div>';
    }
    $('rail').innerHTML = h;
  }

  function renderPlayerBar() {
    var pb = $('playerbar');
    if (!pb) { return; }
    var pack = WC.themes ? WC.themes.get(app.settings.skin || 'original') : null;
    var isMiniHub = pack && (pack.layout === 'dashboard-grid' || pack.id === 'minihub');
    pb.style.display = (app.screen === 'music' || isMiniHub) ? 'none' : '';
    pb.innerHTML =
      '<div class="pb-track tap" data-action="go" data-arg="music">' +
      '<div class="js-cover-60">' + cover(null, 60) + '</div>' +
      '<div class="pb-text"><div class="pb-title js-title">—</div><div class="pb-artist js-artist"></div></div></div>' +
      '<div class="pb-progress"><span class="pb-time js-pos">0:00</span>' +
      '<div class="seek pb-seek tap" data-action="seek"><div class="progress"><div class="progress-fill js-fill"></div></div></div>' +
      '<span class="pb-time js-dur">0:00</span></div>' +
      '<div class="pb-controls">' +
      '<div class="pb-btn tap" data-action="previous">' + icon('prev', 30) + '</div>' +
      '<div class="pb-btn pb-btn-primary tap js-play" data-action="toggle">' + icon('play', 32) + '</div>' +
      '<div class="pb-btn tap" data-action="next">' + icon('next', 30) + '</div></div>' +
      '<div class="pb-playback-modes">' +
      '<div class="pb-btn pb-btn-sm tap js-shuffle" data-action="toggleShuffle" title="Aleatório">' + icon('shuffle', 22) + '</div>' +
      '<div class="pb-btn pb-btn-sm tap js-repeat" data-action="cycleRepeat" title="Repetir">' + icon('repeat', 22) + '</div></div>';
  }

  function setAll(cls, html) {
    U.each(U.byClass(cls), function (el) {
      if (el) { el.innerHTML = html; }
    });
  }

  /* Cheap per-tick update of everything bound to the player state. */
  function updatePlayer() {
    var st = app.state;
    var track = st ? trackOf(st.currentTrack) : null;
    var album = albumOf(track);
    var trackChanged = (st ? st.currentTrack : null) + '|' + (st ? st.playing : '') !== app.lastTrack;

    if (trackChanged) {
      app.lastTrack = (st ? st.currentTrack : null) + '|' + (st ? st.playing : '');
      setAll('js-title', esc(track ? track.title : (st ? 'Faixa desconhecida' : 'Sem conexão com o player')));
      setAll('js-artist', esc(track ? artistName(track.artistId) : ''));
      setAll('js-artist-album', esc(track ? artistName(track.artistId) + ' · ' + (album ? album.title : '') : ''));
      setAll('js-cover-60', cover(album, 60));
      setAll('js-cover-96', cover(album, 96));
      setAll('js-cover-200', cover(album, 200));
      U.each(U.byClass('js-play'), function (el) {
        if (!el) { return; }
        var big = U.hasClass(el, 'round-btn-xl') ? 40 : 34;
        el.innerHTML = icon(st && st.playing ? 'pause' : 'play', big);
      });
      if (app.screen === 'music' && (app.ui.musicTab === 'queue' || app.ui.musicDetail)) { refreshLibraryList(); }
    }

    var dur = track ? track.duration : 0;
    var pos = st ? Math.min(st.position, dur) : 0;
    var pct = dur ? Math.round((pos / dur) * 1000) / 10 : 0;
    U.each(U.byClass('js-fill'), function (el) {
      if (el) { el.style.width = pct + '%'; }
    });
    setAll('js-pos', U.formatTime(pos));
    setAll('js-dur', U.formatTime(dur));

    var isShuffle = !!(st && (st.shuffle || st.shuffleEnabled));
    var repeatMode = (st && st.repeatMode) || 'OFF';
    U.each(U.byClass('js-shuffle'), function (el) {
      if (!el) { return; }
      if (isShuffle) { U.addClass(el, 'is-active'); } else { U.removeClass(el, 'is-active'); }
    });
    U.each(U.byClass('js-repeat'), function (el) {
      if (!el) { return; }
      if (repeatMode !== 'OFF') { U.addClass(el, 'is-active'); } else { U.removeClass(el, 'is-active'); }
      var rIcon = repeatMode === 'ONE' ? 'repeatOne' : 'repeat';
      var sz = U.hasClass(el, 'round-btn-sm') ? 24 : 22;
      el.innerHTML = icon(rIcon, sz);
    });
  }

  function clockText(d) {
    var h = d.getHours();
    if (app.settings && !app.settings.clock24) { h = h % 12 || 12; }
    return h + ':' + U.pad2(d.getMinutes());
  }

  function updateClock() {
    var t = clockText(new Date());
    var el = $('sb-clock');
    if (el) { el.innerHTML = t; }
    setAll('js-clock-big', t);
  }

  function updateBadge() {
    if (!app.service) { return; }
    var info = app.service.getInfo();
    var el = $('sb-service');
    if (!el) { return; }
    el.className = 'sb-badge ' + (info.connected ? 'is-ok' : 'is-bad');
    el.innerHTML = '<span class="dot"></span><span class="sb-service-label">' + esc(info.label) + '</span>';
  }

  /* ---------------------------------------------------------------------- */
  /* Navigation                                                              */

  function renderScreen() {
    var screen = SCREENS[app.screen];
    var main = $('main');
    if (main && screen) {
      main.innerHTML = '<div class="screen screen-' + app.screen + '">' + screen.render() + '</div>';
    }
    app.lastTrack = null;
    updatePlayer();
    if (app.screen === 'navigation') {
      setTimeout(drawNavigationCanvas, 0);
    }
  }

  function go(name) {
    if (!SCREENS[name]) { name = 'home'; }
    if (app.screen === 'navigation' && name !== 'navigation') {
      if (app.ui.locationTimer) {
        clearInterval(app.ui.locationTimer);
        app.ui.locationTimer = null;
      }
      if (app.service && app.service.setLocationMode) {
        app.service.setLocationMode('NORMAL', function () {});
      }
    }
    app.screen = name;
    applyLook();
    var pack = WC.themes ? WC.themes.get(app.settings.skin || 'original') : null;
    var isMiniHub = pack && (pack.layout === 'dashboard-grid' || pack.id === 'minihub');
    var pb = $('playerbar');
    if (pb) {
      pb.style.display = (name === 'music' || isMiniHub) ? 'none' : '';
    }
    var titleEl = $('sb-title');
    if (titleEl) { titleEl.innerHTML = esc(SCREENS[name].title); }
    renderTopActions();
    for (var i = 0; i < RAIL.length; i++) {
      var rEl = $('rail-' + RAIL[i]);
      if (rEl) {
        U.toggleClass(rEl, 'is-active', RAIL[i] === name);
      }
    }
    renderScreen();
    if (SCREENS[name].load) { SCREENS[name].load(); }
    try { window.location.replace('#' + name); } catch (e) { /* ignore */ }
  }
  app.go = go;

  /* ---------------------------------------------------------------------- */
  /* Actions (triggered by data-action)                                      */

  function after(err) { reportError(err); }

  var ACTIONS = {
    go: function (arg) { go(arg); },
    toggle: function () {
      if (!app.state) { toast('Player indisponível'); return; }
      if (app.state.playing) { app.service.pause(after); } else { app.service.play(after); }
    },
    next: function () { app.service.next(after); },
    previous: function () { app.service.previous(after); },
    toggleShuffle: function () {
      if (!app.service || !app.service.toggleShuffle) { toast('Modo aleatório indisponível'); return; }
      app.service.toggleShuffle(after);
    },
    cycleRepeat: function () {
      if (!app.service || !app.service.cycleRepeat) { toast('Modo de repetição indisponível'); return; }
      app.service.cycleRepeat(after);
    },
    seek: function (arg, el, x) {
      var track = app.state ? trackOf(app.state.currentTrack) : null;
      if (!track) { return; }
      var r = el.getBoundingClientRect();
      var ratio = Math.max(0, Math.min(1, (x - r.left) / (r.right - r.left)));
      app.service.seek(ratio * track.duration, after);
    },
    playTrack: function (arg, el) {
      var ctx = el.getAttribute('data-context');
      var ids = ctx ? ctx.split(',') : null;
      var options = null;
      var detail = app.ui.musicDetail;
      if (detail && detail.type === 'playlist') {
        var isAllMusic = detail.id === 'mh_all';
        if (!isAllMusic && app.library && app.library.playlists) {
          for (var pi = 0; pi < app.library.playlists.length; pi++) {
            if (app.library.playlists[pi].id === detail.id && String(app.library.playlists[pi].name || '').toLowerCase() === 'todas as músicas') { isAllMusic = true; break; }
          }
        }
        if (isAllMusic && ids && ids.length) {
          var rest = [], ri;
          for (ri = 0; ri < ids.length; ri++) { if (ids[ri] !== arg) { rest.push(ids[ri]); } }
          for (ri = rest.length - 1; ri > 0; ri--) {
            var rj = Math.floor(Math.random() * (ri + 1));
            var tmp = rest[ri]; rest[ri] = rest[rj]; rest[rj] = tmp;
          }
          ids = [arg].concat(rest);
          options = { shuffleState: true, fromAllTracks: true };
        } else {
          options = { shuffleState: false };
        }
      }
      app.service.playTrack(arg, ids, after, options);
      if (app.settings.openPlayerOnPlay && app.screen !== 'music') { go('music'); }
    },
    playFile: function (arg) {
      if (!trackOf(arg)) { toast('Arquivo não está na biblioteca'); return; }
      app.service.playTrack(arg, null, after);
      toast('Tocando: ' + trackOf(arg).title);
    },
    musicTab: function (arg) {
      app.ui.musicTab = arg;
      app.ui.musicDetail = null;
      U.each(U.byClass('tab'), function (el) { U.toggleClass(el, 'is-active', el.getAttribute('data-arg') === arg); });
      refreshLibraryList();
      var list = $('lib-list');
      if (list) { list.scrollTop = 0; }
    },
    openAlbum: function (arg) { app.ui.musicDetail = { type: 'album', id: arg }; refreshLibraryList(); $('lib-list').scrollTop = 0; },
    openArtist: function (arg) { app.ui.musicDetail = { type: 'artist', id: arg }; refreshLibraryList(); $('lib-list').scrollTop = 0; },
    openPlaylist: function (arg) { app.ui.musicDetail = { type: 'playlist', id: arg }; refreshLibraryList(); $('lib-list').scrollTop = 0; },
    musicBack: function () { app.ui.musicDetail = null; refreshLibraryList(); },
    openPath: function (arg) { app.ui.filesPath = arg; go('files'); },
    filesUp: function () {
      var p = app.ui.filesPath.replace(/\/[^\/]*$/, '');
      app.ui.filesPath = p || '/';
      go('files');
    },
    selectRoute: function (arg) {
      var routes = app.routes || [];
      for (var i = 0; i < routes.length; i++) {
        if (routes[i].id === arg) {
          app.ui.activeRoute = routes[i];
          toast('Iniciando rota: ' + routes[i].destination);
          renderScreen();
          return;
        }
      }
    },
    cancelNav: function () {
      app.ui.activeRoute = null;
      toast('Rota cancelada');
      renderScreen();
    },
    startLocation: function () {
      if (!app.service || !app.service.startLocation) { toast('GPS indisponível neste modo'); return; }
      app.service.startLocation(function (err, data) {
        if (err) { reportError(err); return; }
        app.location = data || app.location;
        pollNavigationLocation();
      });
    },
    refreshLocation: function () { pollNavigationLocation(); },
    stopLocation: function () {
      if (!app.service || !app.service.stopLocation) { return; }
      app.service.stopLocation(function (err, data) {
        if (err) { reportError(err); return; }
        app.location = data || { supported: true, requested: false, tracking: false, hasFix: false };
        if (app.screen === 'navigation') { renderScreen(); }
      });
    },
    selectMessage: function (arg) {
      var msgs = app.messages || [];
      for (var i = 0; i < msgs.length; i++) {
        if (msgs[i].id === arg) {
          app.ui.selectedMsg = msgs[i];
          msgs[i].unread = false;
          renderScreen();
          return;
        }
      }
    },
    quickReply: function (arg) {
      toast('Resposta enviada: "' + arg + '"');
    },
    openSettings: function (arg) {
      app.ui.settingsSection = arg || 'appearance';
      go('settings');
    },
    homeToggle: function (arg) {
      if (!HOME_TILE_DEFS[arg]) { return; }
      var list = getHomeTiles();
      var idx = U.indexOf(list, arg);
      if (idx > -1) { list.splice(idx, 1); } else { list.push(arg); }
      app.settings.homeTiles = list;
      saveSettings();
      renderScreen();
    },
    homeMove: function (arg, el) {
      var dir = el.getAttribute('data-value');
      var list = getHomeTiles();
      var idx = U.indexOf(list, arg);
      if (idx < 0) { return; }
      var to = dir === 'up' ? idx - 1 : idx + 1;
      if (to < 0 || to >= list.length) { return; }
      var tmp = list[idx]; list[idx] = list[to]; list[to] = tmp;
      app.settings.homeTiles = list;
      saveSettings();
      renderScreen();
    },
    resetHome: function () {
      app.settings.homeTiles = DEFAULT_SETTINGS.homeTiles.slice();
      saveSettings(); renderScreen(); toast('Atalhos restaurados');
    },
    settingsSection: function (arg) { app.ui.settingsSection = arg; renderScreen(); },
    set: function (key, el) {
      var raw = el.getAttribute('data-value');
      var value = raw === 'true' ? true : raw === 'false' ? false : raw;
      if (app.settings[key] === value) { return; }
      app.settings[key] = value;
      if (key === 'serviceMode') { app.settings.hostAutoDetect = false; }
      saveSettings();
      applyLook();
      if (key === 'skin') {
        renderRail();
        renderTopActions();
        renderPlayerBar();
      }
      if (key === 'serviceMode') { connect(); }
      if (key === 'clock24') { updateClock(); }
      renderScreen();
    },
    saveUrl: function (key) {
      var input = $('input-' + key);
      app.settings[key] = String(input.value || '').replace(/^\s+|\s+$/g, '');
      saveSettings();
      toast('Endereço salvo');
      if (app.settings.serviceMode !== 'mock') { connect(); }
      renderScreen();
    },
    refreshLibrary: function () {
      toast('Atualizando biblioteca…');
      loadData();
      if (app.screen === 'settings') { setTimeout(function () { renderScreen(); }, 250); }
    },
    clearLibraryCache: function () {
      if (app.service && app.service.clearLibraryCache) { app.service.clearLibraryCache(); }
      WC.storage.remove('webcaros.minihub.media.player');
      toast('Cache da biblioteca removido');
      if (app.settings.serviceMode === 'minihub_media') { connect(); }
    },
    testUrl: function (kind) {
      var key = 'minihubUrl';
      var url = String($('input-' + key).value || '').replace(/^\s+|\s+$/g, '');
      var svc = new WC.services.MiniHubMediaCarOSService(url, WC.fixtures);
      if (window.location.protocol === 'https:' && /^http:/i.test(url)) {
        app.ui.pingResult[kind] = { ok: false, text: 'Aviso: página HTTPS não pode chamar endereço http:// (conteúdo misto).' };
        renderScreen();
        return;
      }
      app.ui.pingResult[kind] = { ok: true, text: 'Testando…' };
      renderScreen();
      var started = new Date().getTime();
      svc.ping(function (err) {
        app.ui.pingResult[kind] = err
          ? { ok: false, text: 'Falhou: ' + err.message }
          : { ok: true, text: 'Respondeu em ' + (new Date().getTime() - started) + ' ms' };
        if (app.screen === 'settings') { renderScreen(); }
      });
    },
    removeSkin: function (id) {
      if (!WC.themes || !WC.themes.remove(id)) { toast('Skin não encontrada'); return; }
      app.settings.skin = 'original';
      saveSettings(); applyLook(); renderRail(); renderTopActions(); renderPlayerBar(); renderScreen(); toast('Skin removida');
    },
    pairMiniHub: function () {
      var input = $('mh-auth-code');
      var code = input ? input.value : '';
      if (!app.service || !app.service.pair) { toast('Pareamento indisponível neste modo'); return; }
      var btn = $('mh-auth-submit');
      if (btn) { btn.innerHTML = 'Conectando…'; }
      app.service.pair(code, function (err) {
        if (btn) { btn.innerHTML = 'Conectar'; }
        if (err) { showMiniHubAuth(err.message || 'Não foi possível parear'); return; }
        hideMiniHubAuth();
        toast('MiniHub conectado');
        loadData();
        updateBadge();
      });
    },
    closeMiniHubAuth: function () { hideMiniHubAuth(); },
    soon: function () { toast('Disponível em uma próxima versão'); },
    reload: function () { window.location.reload(); },
    resetAll: function () {
      WC.storage.remove(SETTINGS_KEY);
      WC.storage.remove('webcaros.mock.player');
      WC.storage.remove('webcaros.minihub.media.player');
      window.location.replace('/');
      window.location.reload();
    }
  };

  function fire(el, x) {
    var name = el.getAttribute('data-action');
    var handler = ACTIONS[name];
    if (!handler) { return; }
    try {
      handler(el.getAttribute('data-arg'), el, x);
    } catch (e) {
      if (window.WC_REPORT_ERROR) { window.WC_REPORT_ERROR('Erro na ação ' + name + ': ' + e.message); }
    }
  }

  /* ---------------------------------------------------------------------- */
  /* Touch handling: instant taps (no 300 ms delay), pressed feedback,      */
  /* no page rubber-banding outside .scroll areas.                           */

  function bindInput() {
    var touch = { el: null, x: 0, y: 0, moved: false, last: 0 };

    document.addEventListener('touchstart', function (e) {
      var t = e.touches[0];
      touch.el = U.closestAttr(e.target, 'data-action');
      touch.x = t.clientX;
      touch.y = t.clientY;
      touch.moved = false;
      if (touch.el) { U.addClass(touch.el, 'is-pressed'); }
      var sc = U.closestClass(e.target, 'scroll');
      if (sc) {
        /* Keep the scroller off its edges so iOS never scrolls the page. */
        if (sc.scrollTop <= 0) { sc.scrollTop = 1; }
        else if (sc.scrollTop + sc.offsetHeight >= sc.scrollHeight) { sc.scrollTop = sc.scrollHeight - sc.offsetHeight - 1; }
      }
    }, false);

    document.addEventListener('touchmove', function (e) {
      var t = e.touches[0];
      if (touch.el && (Math.abs(t.clientX - touch.x) > 10 || Math.abs(t.clientY - touch.y) > 10)) {
        touch.moved = true;
        U.removeClass(touch.el, 'is-pressed');
      }
      var tag = e.target.tagName;
      if (!U.closestClass(e.target, 'scroll') && tag !== 'INPUT' && tag !== 'TEXTAREA') { e.preventDefault(); }
    }, false);

    document.addEventListener('touchend', function (e) {
      var el = touch.el;
      touch.el = null;
      if (!el) { return; }
      U.removeClass(el, 'is-pressed');
      if (touch.moved) { return; }
      if (el.tagName === 'A') { return; } /* allow real links to navigate */
      e.preventDefault();
      touch.last = new Date().getTime();
      fire(el, touch.x);
    }, false);

    document.addEventListener('touchcancel', function () {
      if (touch.el) { U.removeClass(touch.el, 'is-pressed'); }
      touch.el = null;
    }, false);

    document.addEventListener('change', function (e) {
      var input = e.target;
      if (!input || input.id !== 'theme-file' || !input.files || !input.files[0]) { return; }
      var file = input.files[0];
      if (file.size && file.size > 32768) { toast('Tema maior que 32 KB'); input.value = ''; return; }
      if (!window.FileReader) { toast('Este navegador não permite importar arquivos'); return; }
      var reader = new FileReader();
      reader.onload = function () {
        try {
          var pack = WC.themes.importText(String(reader.result || ''));
          app.settings.skin = pack.id;
          saveSettings();
          applyLook();
          renderRail();
          renderTopActions();
          renderPlayerBar();
          renderScreen();
          toast('Skin instalada: ' + pack.name);
        } catch (err) { toast('Skin inválida: ' + (err.message || 'erro')); }
      };
      reader.onerror = function () { toast('Não foi possível ler o arquivo'); };
      reader.readAsText(file);
    }, false);

    /* Mouse / desktop fallback; ignore the synthetic click after a touch. */
    document.addEventListener('click', function (e) {
      if (new Date().getTime() - touch.last < 800) { return; }
      var el = U.closestAttr(e.target, 'data-action');
      if (el && el.tagName !== 'A') { fire(el, e.clientX); }
    }, false);
  }

  function showMiniHubAuth(message) {
    var overlay = $('mh-auth-overlay');
    var err = $('mh-auth-error');
    if (!overlay) { return; }
    overlay.style.display = 'block';
    if (err) { err.innerHTML = esc(message || 'Digite a senha ou PIN exibido no MiniHub.'); }
    var input = $('mh-auth-code');
    if (input) { try { input.focus(); } catch (e) {} }
  }

  function hideMiniHubAuth() {
    var overlay = $('mh-auth-overlay');
    if (overlay) { overlay.style.display = 'none'; }
    var err = $('mh-auth-error');
    if (err) { err.innerHTML = ''; }
  }

  function detectMiniHubHost(done) {
    if (!app.settings.hostAutoDetect || window.location.protocol === 'file:') { done(); return; }
    WC.http('GET', '/api/v1/health', null, 2200, function (err, data) {
      if (!err && data && Number(data.protocolVersion) === 1 && String(data.server || '').toLowerCase().indexOf('minihub') > -1) {
        app.settings.serviceMode = 'minihub_media';
        app.settings.minihubUrl = '';
        saveSettings();
      }
      done();
    });
  }

  /* ---------------------------------------------------------------------- */
  /* Service wiring                                                          */

  function indexLibrary(lib) {
    app.library = lib;
    app.index = { tracks: {}, albums: {}, artists: {} };
    if (!lib) { return; }
    var i;
    for (i = 0; i < lib.tracks.length; i++) { app.index.tracks[lib.tracks[i].id] = lib.tracks[i]; }
    for (i = 0; i < lib.albums.length; i++) { app.index.albums[lib.albums[i].id] = lib.albums[i]; }
    for (i = 0; i < lib.artists.length; i++) { app.index.artists[lib.artists[i].id] = lib.artists[i]; }
  }

  function loadData() {
    app.service.getLibrary(function (err, lib) {
      indexLibrary(err ? null : lib);
      app.lastTrack = null;
      if (app.screen === 'music') { refreshLibraryList(); }
      updatePlayer();
    });
    app.service.getPlayerState(function (err, state) {
      if (!err) { app.state = state; updatePlayer(); }
    });
    app.devices = null;
    if (app.screen === 'devices' || app.screen === 'files') { go(app.screen); }
  }

  function connect() {
    if (app.service) { app.service.stop(); }
    app.state = null;
    app.service = WC.services.create(app.settings, WC.fixtures);
    app.service.on('state', function (state) {
      app.state = state;
      updatePlayer();
    });
    app.service.on('status', function () {
      updateBadge();
    });
    app.service.on('auth', function (info) {
      if (info && info.required) { showMiniHubAuth(info.message); }
      else { hideMiniHubAuth(); }
    });
    app.service.on('switched', function () {
      loadData();
    });
    updateBadge();
    app.service.start();
    loadData();
  }

  /* ---------------------------------------------------------------------- */
  /* Boot                                                                    */

  function boot() {
    app.settings = U.extend({}, DEFAULT_SETTINGS, WC.storage.get(SETTINGS_KEY, {}));
    /* V7: cloud/hybrid were frozen. Migrate stale saved modes to the local MiniHub host. */
    if (app.settings.serviceMode === 'cloud' || app.settings.serviceMode === 'hybrid') {
      app.settings.serviceMode = 'minihub_media';
      app.settings.minihubUrl = '';
      saveSettings();
    }
    applyLook();
    renderRail();
    renderTopActions();
    renderPlayerBar();
    bindInput();

    detectMiniHubHost(function () {
      connect();
      var hash = String(window.location.hash || '').replace('#', '');
      go(SCREENS[hash] ? hash : app.settings.startScreen);
      updateClock();
      setInterval(updateClock, 10000);
      window.WC_BOOTED = true;
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot, false);
  } else {
    boot();
  }
})(window, document);
