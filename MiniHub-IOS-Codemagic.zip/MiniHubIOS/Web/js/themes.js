/*
 * Web MiniHub Theme Manager — ES5 ONLY for Safari 9 / iOS 9.
 * Theme packs are DATA (JSON), never executable CSS/JS.
 */
(function (window, document) {
  'use strict';
  var WC = window.WC = window.WC || {};
  var STORAGE_KEY = 'webcaros.customThemes';
  var STYLE_ID = 'webcaros-theme-style';
  var MAX_BYTES = 32768;

  var builtins = {
    original: { id: 'original', name: 'Original', layout: 'classic', palette: { bg:'#0b0f14', surface:'#151b23', surface2:'#1b232d', border:'#222b36', text:'#e8edf2', muted:'#8a96a3', soft:'#b8c2cc', accent:'#ffb020', accentText:'#0b0f14' } },
    midnight: { id: 'midnight', name: 'Midnight', palette: { bg:'#000000', surface:'#0b0d10', surface2:'#12161b', border:'#242a31', text:'#f2f4f6', muted:'#8d949c', soft:'#c4c9cf', accent:'#8b9cff', accentText:'#08090c' } },
    ocean: { id: 'ocean', name: 'Ocean', palette: { bg:'#07131b', surface:'#0c202b', surface2:'#12303d', border:'#1c4554', text:'#edfaff', muted:'#87a9b6', soft:'#bad4dd', accent:'#3fc1ff', accentText:'#06131a' } },
    retro: { id: 'retro', name: 'Retro Amber', layout: 'classic', palette: { bg:'#120d05', surface:'#211707', surface2:'#2c1e08', border:'#4b3512', text:'#ffe8b5', muted:'#b99a62', soft:'#e1c184', accent:'#ffb020', accentText:'#160e02' } },
    minihub: { id: 'minihub', name: 'MiniHub Classic', layout: 'dashboard-grid', palette: { bg:'#111018', surface:'#171719', surface2:'#222129', border:'#34323d', text:'#ffffff', muted:'#aaa8b2', soft:'#dedce4', accent:'#ff6267', accentText:'#171719' } }
  };

  function storageGet() {
    return WC.storage ? WC.storage.get(STORAGE_KEY, {}) : {};
  }
  function storageSet(v) { if (WC.storage) { WC.storage.set(STORAGE_KEY, v); } }
  function safeId(v) { return String(v || '').toLowerCase().replace(/[^a-z0-9_-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').slice(0, 32); }
  function isHex(v) { return /^#[0-9a-fA-F]{6}$/.test(String(v || '')); }
  function validate(pack) {
    var required = ['bg','surface','surface2','border','text','muted','soft','accent','accentText'];
    if (!pack || typeof pack !== 'object') { throw new Error('Tema inválido.'); }
    var id = safeId(pack.id);
    if (!id) { throw new Error('O tema precisa de um id válido.'); }
    if (!pack.name || String(pack.name).length > 40) { throw new Error('Nome do tema inválido.'); }
    if (!pack.palette || typeof pack.palette !== 'object') { throw new Error('Palette ausente.'); }
    for (var i = 0; i < required.length; i++) {
      if (!isHex(pack.palette[required[i]])) { throw new Error('Cor inválida: ' + required[i] + '. Use #RRGGBB.'); }
    }
    var layout = pack.layout === 'dashboard-grid' ? 'dashboard-grid' : 'classic';
    return { id:id, name:String(pack.name), author:String(pack.author || ''), version:String(pack.version || '1'), layout:layout, palette:pack.palette };
  }
  function all() {
    var out = {}, k, custom = storageGet();
    for (k in builtins) { if (builtins.hasOwnProperty(k)) { out[k] = builtins[k]; } }
    for (k in custom) { if (custom.hasOwnProperty(k)) { out[k] = custom[k]; } }
    return out;
  }
  function get(id) { return all()[id] || builtins.original; }
  function cssFor(p) {
    return 'body,#app{background:'+p.bg+';color:'+p.text+'}' +
      '#statusbar,#rail,#playerbar{background:'+p.bg+';border-color:'+p.border+'}' +
      '.tile,.np-card,.device,.seg,.note,.list-row,.tab,.field,.mh-hero,.mh-tile,.module-hero,.module-card,.home-config-row,body.skin-dashboard-grid .mh-hero,body.skin-dashboard-grid .mh-tile,body.skin-dashboard-grid .module-hero,body.skin-dashboard-grid .module-card,body.skin-dashboard-grid .home-config-row{border-color:'+p.border+'}' +
      '.tile,.np-card,.device,.seg,.note,.mh-hero,.mh-tile,.module-hero,.module-card,.home-config-row,body.skin-dashboard-grid .mh-hero,body.skin-dashboard-grid .mh-tile,body.skin-dashboard-grid .module-hero,body.skin-dashboard-grid .module-card,body.skin-dashboard-grid .home-config-row{background:'+p.surface+'}' +
      '.btn{background:'+p.surface2+';color:'+p.text+'}' +
      '.input{background:'+p.bg+';color:'+p.text+';border-color:'+p.border+'}' +
      '.row-title,.device-name,.info-title,.field-label,.files-path,.np-title,.pb-title{color:'+p.text+'}' +
      '.row-sub,.row-meta,.device-role,.status-line,.seg-btn,.field-help,.map-caption,.note,.info-text{color:'+p.muted+'}' +
      '.accent-text,.tile-icon,.mh-tile-icon,.module-icon,.module-card-icon,.home-config-icon,.is-current .row-title,.is-current .row-num,body.skin-dashboard-grid .mh-tile-icon,body.skin-dashboard-grid .module-icon,body.skin-dashboard-grid .module-card-icon,body.skin-dashboard-grid .home-config-icon{color:'+p.accent+'}' +
      '.progress-fill,.round-btn-primary,.pb-btn-primary,.tab.is-active,.seg-btn.is-active,.rail-btn.is-active:before,.mini-btn-add,body.skin-dashboard-grid .round-btn-primary,body.skin-dashboard-grid #playerbar .pb-btn-primary,body.skin-dashboard-grid .mini-btn-add{background:'+p.accent+'}' +
      '.seg-btn.is-active,.tab.is-active{color:'+p.accentText+'}' +
      '.settings-nav,.files-head,.field{border-color:'+p.border+'}';
  }
  function apply(id) {
    var pack = get(id), style = document.getElementById(STYLE_ID);
    if (!style) { style = document.createElement('style'); style.id = STYLE_ID; document.getElementsByTagName('head')[0].appendChild(style); }
    if (style.styleSheet) { style.styleSheet.cssText = cssFor(pack.palette); } else { style.textContent = cssFor(pack.palette); }
    return pack;
  }
  function importText(text) {
    if (!text || text.length > MAX_BYTES) { throw new Error('Tema vazio ou maior que 32 KB.'); }
    var pack = validate(JSON.parse(text));
    if (builtins[pack.id]) { throw new Error('Este id é reservado por um tema interno.'); }
    var custom = storageGet();
    custom[pack.id] = pack;
    storageSet(custom);
    return pack;
  }
  function remove(id) {
    var custom = storageGet();
    if (!custom[id]) { return false; }
    delete custom[id]; storageSet(custom); return true;
  }
  function isCustom(id) { return !!storageGet()[id]; }

  WC.themes = { all:all, get:get, apply:apply, importText:importText, remove:remove, isCustom:isCustom, maxBytes:MAX_BYTES };
})(window, document);
