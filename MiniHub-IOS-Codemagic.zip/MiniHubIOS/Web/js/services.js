/*
 * CarOSService — the only way the UI talks to "the system".
 * The UI never knows where data comes from.
 *
 * Every implementation exposes the same callback-based interface
 * (callbacks instead of Promises: maximum compatibility with iOS 9):
 *
 *   getPlayerState(cb)          cb(err, state)
 *   play(cb) pause(cb) next(cb) previous(cb)
 *   seek(seconds, cb) setVolume(0..1, cb)
 *   playTrack(trackId, queueIds, cb)
 *   getQueue(cb) getLibrary(cb) getDevices(cb) getFiles(path, cb)
 *   ping(cb)                    cb(err, info)
 *   start() stop()              begin/end pushing 'state' events
 *   on('state', fn)  on('status', fn)
 *   getInfo()                   { id, label, connected }
 *
 * State shape: { currentTrack, position, playing, volume, queue: [ids] }
 *
 * ES5 ONLY.
 */
(function (window) {
  'use strict';

  var WC = window.WC;
  var U = WC.util;

  var METHODS = ['getPlayerState', 'play', 'pause', 'next', 'previous', 'seek', 'setVolume',
    'playTrack', 'getQueue', 'getLibrary', 'getDevices', 'getFiles', 'getRoutes', 'getMessages',
    'getLocation', 'startLocation', 'stopLocation', 'toggleShuffle', 'cycleRepeat', 'getNavigationState', 'ping'];

  function noop() {}
  function later(fn) { setTimeout(fn, 0); }

  function inherit(Child, Parent) {
    function F() {}
    F.prototype = Parent.prototype;
    Child.prototype = new F();
    Child.prototype.constructor = Child;
  }

  function BaseService() {
    this.emitter = new WC.Emitter();
    this.connected = false;
  }
  BaseService.prototype.on = function (name, fn) { this.emitter.on(name, fn); return this; };
  BaseService.prototype.off = function (name, fn) { this.emitter.off(name, fn); return this; };
  BaseService.prototype.getInfo = function () {
    return { id: this.id, label: this.label, connected: this.connected };
  };
  BaseService.prototype._setConnected = function (value) {
    if (this.connected !== value) {
      this.connected = value;
      this.emitter.emit('status', this.getInfo());
    }
  };

  /* ====================================================================== */
  /* MockCarOSService — simulates a remote player entirely in the browser.  */
  /* State is persisted, and on reload the position is advanced by the time */
  /* that passed, mimicking a server that kept playing while Safari closed. */

  var MOCK_KEY = 'webcaros.mock.player';

  function MockCarOSService(fixtures, options) {
    BaseService.call(this);
    options = options || {};
    this.id = options.id || 'mock';
    this.label = options.label || 'Demo';
    this.connected = true;
    this.storageKey = options.storageKey || MOCK_KEY;
    this.fixtures = fixtures;
    this.timer = null;
    this.audio = (typeof WC !== 'undefined' && WC.audio) ? WC.audio : null;
    this.trackIndex = {};
    var tracks = fixtures.library.tracks;
    for (var i = 0; i < tracks.length; i++) { this.trackIndex[tracks[i].id] = tracks[i]; }
    this.state = this._restore();
    this._bindAudio();
  }
  inherit(MockCarOSService, BaseService);

  MockCarOSService.prototype._bindAudio = function () {
    var self = this;
    if (!this.audio) { return; }

    this.audio.on('timeupdate', function (data) {
      if (!self.state.playing) { return; }
      if (typeof data.currentTime === 'number' && !isNaN(data.currentTime)) {
        self.state.position = Math.round(data.currentTime * 10) / 10;
      }
      var track = self.trackIndex[self.state.currentTrack];
      if (track && typeof data.duration === 'number' && !isNaN(data.duration) && data.duration > 0) {
        track.duration = Math.round(data.duration);
      }
      self._changed();
    });

    this.audio.on('ended', function () {
      var i = U.indexOf(self.state.queue, self.state.currentTrack);
      var repeat = self.state.repeatMode || 'OFF';
      var nextId = null;
      if (repeat === 'ONE' && self.state.currentTrack) {
        nextId = self.state.currentTrack;
      } else if (i > -1 && i < self.state.queue.length - 1) {
        nextId = self.state.queue[i + 1];
      } else if (repeat === 'ALL' && self.state.queue.length) {
        nextId = self.state.queue[0];
      }
      if (nextId) {
        self.state.currentTrack = nextId;
        self.state.position = 0;
        self.state.playing = true;
        var track = self.trackIndex[nextId];
        if (track && track.src) {
          self.audio.load(track.src);
          self.audio.seek(0);
          self.audio.play();
        }
      } else {
        self.state.position = 0;
        self.state.playing = false;
      }
      self._changed();
    });

    this.audio.on('interrupted', function () {
      self.state.playing = false;
      self._changed();
    });

    this.audio.on('resumed', function () {
      self.state.playing = true;
      self._changed();
    });

    this.audio.on('error', function () {
      self.state.playing = false;
      self._changed();
    });
  };

  MockCarOSService.prototype._restore = function () {
    var saved = WC.storage.get(this.storageKey, null);
    var state = U.clone(saved && saved.state ? saved.state : this.fixtures.initialPlayerState);
    if (!this.trackIndex[state.currentTrack]) { state = U.clone(this.fixtures.initialPlayerState); }
    // Rule 12: Always restore in PAUSED state on reload, waiting for user play
    state.playing = false;
    return state;
  };

  MockCarOSService.prototype._save = function () {
    WC.storage.set(this.storageKey, { state: this.state, savedAt: new Date().getTime() });
  };

  /* Moves the playhead forward, rolling over to the next tracks in the queue. */
  MockCarOSService.prototype._advance = function (state, seconds) {
    var guard = 0;
    state.position += seconds;
    while (guard++ < 200) {
      var track = this.trackIndex[state.currentTrack];
      if (!track || state.position < track.duration) { return; }
      state.position -= track.duration;
      var i = U.indexOf(state.queue, state.currentTrack);
      var repeat = state.repeatMode || 'OFF';
      if (repeat === 'ONE' && state.currentTrack) {
        state.position = 0;
        return;
      }
      if (i < 0 || i >= state.queue.length - 1) {
        if (repeat === 'ALL' && state.queue.length) {
          state.currentTrack = state.queue[0];
          continue;
        }
        state.position = 0;
        state.playing = false;
        return;
      }
      state.currentTrack = state.queue[i + 1];
    }
  };

  MockCarOSService.prototype._changed = function (cb) {
    this._save();
    var snapshot = U.clone(this.state);
    this.emitter.emit('state', snapshot);
    if (cb) { later(function () { cb(null, snapshot); }); }
  };

  MockCarOSService.prototype.start = function () {
    var self = this;
    if (this.timer) { return; }
    var last = new Date().getTime();
    this.timer = setInterval(function () {
      var now = new Date().getTime();
      var delta = (now - last) / 1000;
      last = now;
      if (!self.state.playing) { return; }
      /* Never fake progress for a track that has a real audio source.
         While loading (or after a media failure), the UI must not advance
         unless HTMLAudioElement reports real timeupdate events. */
      var currentTrack = self.trackIndex[self.state.currentTrack];
      if (self.audio && currentTrack && currentTrack.src) {
        return;
      }
      self._advance(self.state, delta);
      self._changed();
    }, 1000);
    this.emitter.emit('status', this.getInfo());
    this.emitter.emit('state', U.clone(this.state));
  };
  MockCarOSService.prototype.stop = function () {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    if (this.audio) { this.audio.pause(); }
  };

  MockCarOSService.prototype.getPlayerState = function (cb) {
    var s = U.clone(this.state);
    later(function () { cb(null, s); });
  };
  MockCarOSService.prototype.play = function (cb) {
    this.state.playing = true;
    var track = this.trackIndex[this.state.currentTrack];
    if (this.audio && track && track.src) {
      this.audio.load(track.src);
      if (this.state.position > 0 && Math.abs((this.audio.position() || 0) - this.state.position) > 1) {
        this.audio.seek(this.state.position);
      }
      if (typeof this.state.volume === 'number') {
        this.audio.setVolume(this.state.volume);
      }
      this.audio.play();
    }
    this._changed(cb);
  };
  MockCarOSService.prototype.pause = function (cb) {
    this.state.playing = false;
    if (this.audio) {
      this.audio.pause();
    }
    this._changed(cb);
  };
  MockCarOSService.prototype.next = function (cb) {
    var i = U.indexOf(this.state.queue, this.state.currentTrack);
    var nextId = null;
    if (i > -1 && i < this.state.queue.length - 1) {
      nextId = this.state.queue[i + 1];
    } else if ((this.state.repeatMode || 'OFF') === 'ALL' && this.state.queue.length) {
      nextId = this.state.queue[0];
    }
    if (nextId) {
      this.state.currentTrack = nextId;
      this.state.position = 0;
      var track = this.trackIndex[nextId];
      if (this.audio && track && track.src) {
        this.audio.load(track.src);
        this.audio.seek(0);
        if (this.state.playing) { this.audio.play(); }
      }
    }
    this._changed(cb);
  };
  MockCarOSService.prototype.previous = function (cb) {
    var i = U.indexOf(this.state.queue, this.state.currentTrack);
    /* Car-stereo convention: restart the track unless we are near its start. */
    if (this.state.position > 3 || i <= 0) {
      this.state.position = 0;
      if (this.audio) {
        this.audio.seek(0);
        if (this.state.playing) { this.audio.play(); }
      }
    } else {
      var prevId = this.state.queue[i - 1];
      this.state.currentTrack = prevId;
      this.state.position = 0;
      var track = this.trackIndex[prevId];
      if (this.audio && track && track.src) {
        this.audio.load(track.src);
        this.audio.seek(0);
        if (this.state.playing) { this.audio.play(); }
      }
    }
    this._changed(cb);
  };
  MockCarOSService.prototype.seek = function (seconds, cb) {
    var track = this.trackIndex[this.state.currentTrack];
    var maxSec = track ? track.duration : 0;
    var target = Math.max(0, Math.min(maxSec, seconds));
    this.state.position = target;
    if (this.audio && track && track.src) {
      this.audio.seek(target);
    }
    this._changed(cb);
  };
  MockCarOSService.prototype.setVolume = function (volume, cb) {
    var v = Math.max(0, Math.min(1, Math.round(volume * 100) / 100));
    this.state.volume = v;
    if (this.audio) {
      this.audio.setVolume(v);
    }
    this._changed(cb);
  };
  MockCarOSService.prototype.toggleShuffle = function (cb) {
    this.state.shuffle = !this.state.shuffle;
    this._changed(cb);
  };
  MockCarOSService.prototype.cycleRepeat = function (cb) {
    var modes = ['OFF', 'ALL', 'ONE'];
    var idx = U.indexOf(modes, this.state.repeatMode || 'OFF');
    this.state.repeatMode = modes[(idx + 1) % modes.length];
    this._changed(cb);
  };
  MockCarOSService.prototype.getNavigationState = function (cb) {
    var nav = { active: false, hasNotification: false };
    if (cb) { later(function () { cb(null, nav); }); }
  };
  MockCarOSService.prototype.playTrack = function (trackId, queueIds, cb) {
    if (!this.trackIndex[trackId]) { if (cb) { later(function () { cb(new Error('Faixa não encontrada')); }); } return; }
    if (queueIds && queueIds.length) { this.state.queue = queueIds.slice(); }
    if (U.indexOf(this.state.queue, trackId) < 0) { this.state.queue.push(trackId); }
    this.state.currentTrack = trackId;
    this.state.position = 0;
    this.state.playing = true;
    var track = this.trackIndex[trackId];
    if (this.audio && track && track.src) {
      this.audio.load(track.src);
      this.audio.seek(0);
      if (typeof this.state.volume === 'number') {
        this.audio.setVolume(this.state.volume);
      }
      this.audio.play();
    }
    this._changed(cb);
  };
  MockCarOSService.prototype.getQueue = function (cb) {
    var q = this.state.queue.slice();
    later(function () { cb(null, q); });
  };
  MockCarOSService.prototype.getLibrary = function (cb) {
    var lib = this.fixtures.library;
    later(function () { cb(null, lib); });
  };
  MockCarOSService.prototype.getDevices = function (cb) {
    var d = this.fixtures.devices;
    later(function () { cb(null, d); });
  };
  MockCarOSService.prototype.getRoutes = function (cb) {
    var r = this.fixtures.routes || [];
    later(function () { cb(null, r); });
  };
  MockCarOSService.prototype.getLocation = function (cb) {
    if (window.MiniHubIOS && window.MiniHubIOS.available) { window.MiniHubIOS.getLocation(cb); return; }
    later(function () { cb(null, { supported: false, tracking: false, hasFix: false, message: 'GPS nativo indisponível' }); });
  };
  MockCarOSService.prototype.startLocation = function (cb) {
    if (window.MiniHubIOS && window.MiniHubIOS.available) { window.MiniHubIOS.startLocation(cb); return; }
    later(function () { if (cb) { cb(null, { supported: false, started: false }); } });
  };
  MockCarOSService.prototype.stopLocation = function (cb) {
    if (window.MiniHubIOS && window.MiniHubIOS.available) { window.MiniHubIOS.stopLocation(cb); return; }
    later(function () { if (cb) { cb(null, { supported: false, started: false }); } });
  };
  MockCarOSService.prototype.getMessages = function (cb) {
    var m = this.fixtures.messages || [];
    later(function () { cb(null, m); });
  };
  MockCarOSService.prototype.getFiles = function (path, cb) {
    var items = this.fixtures.files[path];
    later(function () {
      if (!items) { cb(new Error('Pasta não encontrada')); return; }
      cb(null, { path: path, items: items });
    });
  };
  MockCarOSService.prototype.ping = function (cb) {
    var info = this.getInfo();
    later(function () { cb(null, info); });
  };
  MockCarOSService.prototype.reset = function () {
    WC.storage.remove(this.storageKey);
    this.state = U.clone(this.fixtures.initialPlayerState);
    this._changed();
  };

  /* ====================================================================== */
  /* MiniHubMediaCarOSService — real MiniHub library, audio stays on iPad.  */
  /*                                                                         */
  /* This adapter deliberately does NOT command HostPlayer. It reads the     */
  /* Android music catalogue and streams /api/media/stream into WC.audio,   */
  /* preserving the iPad as the sound output. Same-origin LAN mode is the    */
  /* preferred setup because an HTTPS page cannot call an HTTP MiniHub.      */

  function mhBase(baseUrl) {
    return String(baseUrl || '').replace(/\/+$/, '');
  }

  function mhJoin(baseUrl, path) {
    var b = mhBase(baseUrl);
    return b ? b + path : path;
  }

  function mhHash(text) {
    var s = String(text || 'same-origin'), h = 0, i;
    for (i = 0; i < s.length; i++) { h = ((h << 5) - h + s.charCodeAt(i)) | 0; }
    return String(Math.abs(h));
  }

  function mhArray(data) {
    if (!data) { return []; }
    if (Object.prototype.toString.call(data) === '[object Array]') { return data; }
    if (data.tracks && typeof data.tracks.length === 'number') { return data.tracks; }
    if (data.items && typeof data.items.length === 'number') { return data.items; }
    if (data.music && typeof data.music.length === 'number') { return data.music; }
    if (data.library && data.library.tracks && typeof data.library.tracks.length === 'number') { return data.library.tracks; }
    return [];
  }

  function mhSeconds(item) {
    var ms = Number(item.durationMs || item.duration_ms || 0);
    if (ms > 0) { return Math.max(1, Math.round(ms / 1000)); }
    var sec = Number(item.duration || item.durationSec || item.durationSeconds || item.length || 0);
    return sec > 0 ? Math.max(1, Math.round(sec)) : 0;
  }

  function normalizeMiniHubLibrary(data, baseUrl) {
    var raw = mhArray(data);
    var artists = [], albums = [], tracks = [], artistMap = {}, albumMap = {};
    var colors = [
      ['#ff686b', '#572326'], ['#50b7ff', '#15384f'], ['#f2b84b', '#594014'],
      ['#7bd389', '#234b2c'], ['#b77cff', '#3e2558'], ['#55d6be', '#19483f']
    ];
    var i;

    function artistIdFor(name) {
      var key = String(name || 'Desconhecido');
      if (!artistMap[key]) {
        var id = 'mh_ar_' + (artists.length + 1);
        artistMap[key] = id;
        artists.push({ id: id, name: key });
      }
      return artistMap[key];
    }

    function albumIdFor(title, artistId) {
      var name = String(title || 'Sem álbum');
      var key = artistId + '|' + name;
      if (!albumMap[key]) {
        var id = 'mh_al_' + (albums.length + 1);
        albumMap[key] = id;
        albums.push({ id: id, title: name, artistId: artistId, year: null, color: colors[albums.length % colors.length] });
      }
      return albumMap[key];
    }

    for (i = 0; i < raw.length; i++) {
      var item = raw[i] || {};
      var rid = item.id;
      if (rid === undefined || rid === null || rid === '') { rid = item.fileId; }
      if (rid === undefined || rid === null || rid === '') { rid = item.trackId; }
      if (rid === undefined || rid === null || rid === '') { rid = item.mediaId; }
      if (rid === undefined || rid === null || rid === '') { rid = 'item-' + (i + 1); }
      rid = String(rid);
      var title = String(item.title || item.name || item.displayName || ('Faixa ' + (i + 1)));
      var artistName = String(item.artist || item.artistName || 'Desconhecido');
      if (!artistName || artistName === '<unknown>') { artistName = 'Desconhecido'; }
      var albumName = String(item.album || item.albumName || 'Sem álbum');
      if (!albumName || albumName === '<unknown>') { albumName = 'Sem álbum'; }
      var artistId = artistIdFor(artistName);
      var albumId = albumIdFor(albumName, artistId);
      var stream = item.streamUrl || item.stream || item.url || null;
      if (stream && !/^https?:\/\//i.test(stream) && stream.charAt(0) === '/') { stream = mhJoin(baseUrl, stream); }
      if (!stream) { stream = mhJoin(baseUrl, '/api/v1/media/stream?id=' + encodeURIComponent(rid)); }
      tracks.push({
        id: rid,
        title: title,
        artistId: artistId,
        albumId: albumId,
        duration: mhSeconds(item),
        src: stream,
        source: 'minihub'
      });
    }

    return {
      artists: artists,
      albums: albums,
      tracks: tracks,
      playlists: tracks.length ? [{ id: 'mh_all', name: 'Todas as músicas', trackIds: (function () {
        var ids = [], j; for (j = 0; j < tracks.length; j++) { ids.push(tracks[j].id); } return ids;
      })() }] : []
    };
  }

  function MiniHubMediaCarOSService(baseUrl, fallbackFixtures) {
    BaseService.call(this);
    this.id = 'minihub-media';
    this.label = 'MiniHub · áudio no iPad';
    this.baseUrl = mhBase(baseUrl);
    this.cacheKey = 'webcaros.minihub.library.' + mhHash(this.baseUrl || 'same-origin');
    this.library = null;
    this.cacheSavedAt = 0;
    this.remoteError = null;
    this.authRequired = false;
    this.connected = false;
    this.syncTimer = null;
    this.syncBusy = false;
    this.syncStarted = false;
    this.outputReady = false;
    this.applyingRemote = false;
    this.lastPublishedTrackId = null;
    this.instanceId = 'wmh_' + String(new Date().getTime()) + '_' + String(Math.floor(Math.random() * 100000));
    this.epoch = Math.floor(new Date().getTime() / 1000);
    this.lastAckCommandId = 0;
    this.lastCanonicalVersion = 0;

    /* Load catalogue metadata BEFORE restoring player state. This lets the
       local player validate a persisted currentTrack against the cached real
       MiniHub library instead of discarding it during construction. */
    var saved = WC.storage.get(this.cacheKey, null);
    var cachedLibrary = saved && saved.library && saved.library.tracks ? saved.library : null;
    if (cachedLibrary) {
      this.library = cachedLibrary;
      this.cacheSavedAt = Number(saved.savedAt || 0);
    }
    var initialId = cachedLibrary && cachedLibrary.tracks.length ? cachedLibrary.tracks[0].id : null;
    var initialQueue = [], ci;
    if (cachedLibrary) {
      for (ci = 0; ci < cachedLibrary.tracks.length; ci++) { initialQueue.push(cachedLibrary.tracks[ci].id); }
    }
    var emptyFixtures = {
      library: cachedLibrary || { artists: [], albums: [], tracks: [], playlists: [] },
      devices: [], files: { '/': [] }, routes: [], messages: [],
      initialPlayerState: { currentTrack: initialId, position: 0, playing: false, volume: 0.8, queue: initialQueue }
    };
    this.local = new MockCarOSService(emptyFixtures, {
      id: 'minihub-media-local', label: 'Player local', storageKey: 'webcaros.minihub.media.player'
    });

    var self = this;
    this._forwardState = function (state) {
      self.emitter.emit('state', state);
      if (self.syncStarted && self.outputReady && !self.applyingRemote && state && state.currentTrack && state.currentTrack !== self.lastPublishedTrackId) {
        self._publishQueueState(state);
      }
    };
    this.local.on('state', this._forwardState);
  }
  inherit(MiniHubMediaCarOSService, BaseService);

  MiniHubMediaCarOSService.prototype._request = function (path, cb) {
    var self = this;
    WC.http('GET', mhJoin(this.baseUrl, path), null, 7000, function (err, data) {
      self.remoteError = err || null;
      if (err && err.status === 401) {
        self.authRequired = true;
        self.emitter.emit('auth', { required: true, message: (err.data && err.data.error) || 'Pareamento necessário' });
      } else if (!err && self.authRequired) {
        self.authRequired = false;
        self.emitter.emit('auth', { required: false });
      }
      self._setConnected(!err || (err && err.status === 401));
      cb(err, data);
    });
  };

  MiniHubMediaCarOSService.prototype.pair = function (code, cb) {
    var self = this;
    var value = String(code || '').replace(/^\s+|\s+$/g, '');
    if (!value) { later(function () { cb(new Error('Informe a senha ou PIN')); }); return; }
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/auth/pair'), { code: value }, 8000, function (err, data) {
      if (!err) {
        self.authRequired = false;
        self._setConnected(true);
        self.emitter.emit('auth', { required: false });
        self._ensureWebOutput(function (outputErr) {
          if (outputErr) { return; }
          if (self.local.state && self.local.state.currentTrack) { self._publishQueueState(self.local.state); }
          self._syncRemoteState();
        });
      }
      cb(err, data);
    });
  };

  MiniHubMediaCarOSService.prototype._loadCache = function () {
    var saved = WC.storage.get(this.cacheKey, null);
    if (!saved || !saved.library || !saved.library.tracks) { return false; }
    this.cacheSavedAt = Number(saved.savedAt || 0);
    this._applyLibrary(saved.library, false);
    return true;
  };

  MiniHubMediaCarOSService.prototype._saveCache = function (library) {
    this.cacheSavedAt = new Date().getTime();
    WC.storage.set(this.cacheKey, { savedAt: this.cacheSavedAt, library: library });
  };

  MiniHubMediaCarOSService.prototype._applyLibrary = function (library, emit) {
    this.library = library || { artists: [], albums: [], tracks: [], playlists: [] };
    this.local.fixtures.library = this.library;
    this.local.trackIndex = {};
    var ids = [], i;
    for (i = 0; i < this.library.tracks.length; i++) {
      this.local.trackIndex[this.library.tracks[i].id] = this.library.tracks[i];
      ids.push(this.library.tracks[i].id);
    }

    var st = this.local.state;
    if (!st || !this.local.trackIndex[st.currentTrack]) {
      var existingQueue = (st && st.queue && st.queue.length) ? [] : null;
      if (existingQueue) {
        for (var eq = 0; eq < st.queue.length; eq++) {
          if (this.local.trackIndex[st.queue[eq]]) { existingQueue.push(st.queue[eq]); }
        }
      }
      var queueToUse = (existingQueue && existingQueue.length) ? existingQueue : ids.slice();
      var trackToUse = (st && st.currentTrack && this.local.trackIndex[st.currentTrack]) ? st.currentTrack : (queueToUse.length ? queueToUse[0] : null);
      st = this.local.state = {
        currentTrack: trackToUse,
        position: (st && typeof st.position === 'number') ? st.position : 0,
        playing: false,
        volume: st && typeof st.volume === 'number' ? st.volume : 0.8,
        queue: queueToUse
      };
    } else {
      var q = [], seen = {}, j, qid;
      for (j = 0; j < st.queue.length; j++) {
        qid = st.queue[j];
        if (this.local.trackIndex[qid] && !seen[qid]) { q.push(qid); seen[qid] = true; }
      }
      if (!seen[st.currentTrack]) { q.unshift(st.currentTrack); }
      if (!q.length) { q = ids.slice(); }
      st.queue = q;
      if (st.position < 0) { st.position = 0; }
      st.playing = false;
    }
    if (emit !== false) { this.local._changed(); }
  };

  MiniHubMediaCarOSService.prototype.getInfo = function () {
    return {
      id: this.id,
      label: this.label,
      connected: this.connected,
      libraryCount: this.library && this.library.tracks ? this.library.tracks.length : 0,
      cached: !!(this.library && !this.connected),
      cacheSavedAt: this.cacheSavedAt,
      sameOrigin: !this.baseUrl,
      authRequired: this.authRequired,
      protocolVersion: 1,
      playbackSync: true
    };
  };

  MiniHubMediaCarOSService.prototype._setAuthFromError = function (err) {
    if (err && err.status === 401) {
      this.authRequired = true;
      this.emitter.emit('auth', { required: true, message: (err.data && err.data.error) || 'Pareamento necessário' });
      return true;
    }
    return false;
  };

  MiniHubMediaCarOSService.prototype._ensureWebOutput = function (cb) {
    var self = this;
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/player/output'), { outputMode: 'web' }, 7000, function (err, data) {
      if (err) { self._setAuthFromError(err); if (cb) { cb(err); } return; }
      self.authRequired = false;
      self.outputReady = true;
      self._setConnected(true);
      if (cb) { cb(null, data); }
    });
  };

  MiniHubMediaCarOSService.prototype._publishQueueState = function (state) {
    var self = this;
    if (!this.outputReady || !state || !state.currentTrack || !state.queue || !state.queue.length || this.authRequired) { return; }
    var queue = state.queue.slice();
    var body = { queue: queue, trackId: state.currentTrack, autoPlay: !!state.playing, shuffleState: !!state.shuffle };
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/player/queue'), body, 7000, function (err) {
      if (err) { self._setAuthFromError(err); return; }
      self.lastPublishedTrackId = state.currentTrack;
    });
  };

  MiniHubMediaCarOSService.prototype._applyCanonicalState = function (canonical) {
    if (!canonical || !this.local || !this.local.state) { return; }
    var state = this.local.state;
    var rawQueue = canonical.queueTrackIds || [];
    var queue = [], i, id;
    for (i = 0; i < rawQueue.length; i++) {
      id = String(rawQueue[i] || '');
      if (id && this.local.trackIndex[id] && U.indexOf(queue, id) < 0) { queue.push(id); }
    }
    var targetId = canonical.currentTrackId ? String(canonical.currentTrackId) : null;
    if (targetId && !this.local.trackIndex[targetId]) { return; }
    if (targetId && U.indexOf(queue, targetId) < 0) { queue.unshift(targetId); }

    var queueChanged = queue.length !== state.queue.length;
    if (!queueChanged) {
      for (i = 0; i < queue.length; i++) {
        if (queue[i] !== state.queue[i]) { queueChanged = true; break; }
      }
    }
    var trackChanged = targetId !== state.currentTrack;
    var targetShuffle = !!canonical.shuffle;
    var targetRepeat = canonical.repeatMode || 'OFF';
    var modeChanged = state.shuffle !== targetShuffle || (state.repeatMode || 'OFF') !== targetRepeat;
    var changed = queueChanged || trackChanged || modeChanged;
    var version = Number(canonical.version || 0);

    this.applyingRemote = true;
    try {
      if (queueChanged) { state.queue = queue.slice(); }
      state.shuffle = targetShuffle;
      state.repeatMode = targetRepeat;
      if (trackChanged) {
        if (!targetId) {
          state.currentTrack = null;
          state.position = 0;
          state.playing = false;
          if (this.local.audio) { this.local.audio.pause(); }
        } else {
          var track = this.local.trackIndex[targetId];
          state.currentTrack = targetId;
          state.position = Math.max(0, Number(canonical.positionMs || 0) / 1000);
          state.playing = !!canonical.isPlaying;
          if (this.local.audio && track && track.src) {
            this.local.audio.load(track.src);
            this.local.audio.seek(state.position);
            if (typeof state.volume === 'number') { this.local.audio.setVolume(state.volume); }
            if (state.playing) { this.local.audio.play(); } else { this.local.audio.pause(); }
          }
        }
      }
      if (changed) {
        this.lastPublishedTrackId = state.currentTrack;
        this.local._changed();
      }
      if (version > this.lastCanonicalVersion) { this.lastCanonicalVersion = version; }
    } finally {
      this.applyingRemote = false;
    }
  };

  MiniHubMediaCarOSService.prototype._applyRemoteCommands = function (data) {
    if (!data || !data.commands || typeof data.commands.length !== 'number') { return; }
    var changedTrack = false;
    this.applyingRemote = true;
    try {
      for (var i = 0; i < data.commands.length; i++) {
        var cmd = data.commands[i] || {};
        var id = Number(cmd.commandId || 0);
        if (id && id <= this.lastAckCommandId) { continue; }
        if (cmd.command === 'play') { this.local.play(); }
        else if (cmd.command === 'pause') { this.local.pause(); }
        else if (cmd.command === 'stop') { this.local.pause(); this.local.seek(0); }
        else if (cmd.command === 'next') { this.local.next(); changedTrack = true; }
        else if (cmd.command === 'previous') { this.local.previous(); changedTrack = true; }
        else if (cmd.command === 'seek' && cmd.positionMs !== null && cmd.positionMs !== undefined) { this.local.seek(Number(cmd.positionMs) / 1000); }
        if (id > this.lastAckCommandId) { this.lastAckCommandId = id; }
      }
      if (data.epoch) { this.epoch = Number(data.epoch) || this.epoch; }
      if (changedTrack && this.local.state && this.local.state.currentTrack) { this.lastPublishedTrackId = this.local.state.currentTrack; }
    } finally {
      this.applyingRemote = false;
    }
  };

  MiniHubMediaCarOSService.prototype._syncRemoteState = function () {
    var self = this;
    if (this.syncBusy || this.authRequired || !this.syncStarted || !this.outputReady) { return; }
    var st = this.local.state;
    if (!st) { return; }
    var tr = this.local.trackIndex[st.currentTrack];
    this.syncBusy = true;
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/player/web/state'), {
      instanceId: this.instanceId,
      trackId: st.currentTrack || null,
      isPlaying: !!st.playing,
      playbackState: st.playing ? 'PLAYING' : (st.currentTrack ? 'PAUSED' : 'IDLE'),
      positionMs: Math.max(0, Math.round(Number(st.position || 0) * 1000)),
      durationMs: tr ? Math.max(0, Math.round(Number(tr.duration || 0) * 1000)) : 0,
      lastAckCommandId: this.lastAckCommandId,
      epoch: this.epoch
    }, 6500, function (err, data) {
      self.syncBusy = false;
      if (err) { self._setAuthFromError(err); return; }
      self._setConnected(true);
      self._applyCanonicalState(data && data.canonical);
      self._applyRemoteCommands(data);
    });
  };

  MiniHubMediaCarOSService.prototype.start = function () {
    var self = this;
    if (this.syncStarted) { return; }
    this.syncStarted = true;
    this.outputReady = false;
    this.local.start();
    this._ensureWebOutput(function (err, canonical) {
      if (err) { return; }
      /* V7: Android canonical state wins on reconnect. A cached Safari queue
         must never overwrite a persisted 600+ item/shuffled queue. Only seed
         the server from Safari when the canonical queue is genuinely empty. */
      if (canonical && canonical.queueTrackIds && canonical.queueTrackIds.length) {
        self._applyCanonicalState(canonical);
      } else if (self.local.state && self.local.state.currentTrack) {
        self._publishQueueState(self.local.state);
      }
      self._syncRemoteState();
    });
    this.syncTimer = setInterval(function () { self._syncRemoteState(); }, 1200);
  };
  MiniHubMediaCarOSService.prototype.stop = function () {
    this.syncStarted = false;
    this.outputReady = false;
    if (this.syncTimer) { clearInterval(this.syncTimer); this.syncTimer = null; }
    this.syncBusy = false;
    this.local.stop();
  };
  MiniHubMediaCarOSService.prototype.getPlayerState = function (cb) { this.local.getPlayerState(cb); };
  MiniHubMediaCarOSService.prototype.play = function (cb) { this.local.play(cb); };
  MiniHubMediaCarOSService.prototype.pause = function (cb) { this.local.pause(cb); };
  MiniHubMediaCarOSService.prototype.next = function (cb) { this.local.next(cb); };
  MiniHubMediaCarOSService.prototype.previous = function (cb) { this.local.previous(cb); };
  MiniHubMediaCarOSService.prototype.seek = function (seconds, cb) { this.local.seek(seconds, cb); };
  MiniHubMediaCarOSService.prototype.setVolume = function (volume, cb) { this.local.setVolume(volume, cb); };
  MiniHubMediaCarOSService.prototype.playTrack = function (trackId, queueIds, cb, options) {
    var self = this;
    if (options && options.fromAllTracks) {
      /* V7 Official: Android builds the queue from the complete Room library.
         The Safari list may be paged/cached, so it must not define playback order. */
      WC.http('POST', mhJoin(this.baseUrl, '/api/v1/library/play'), { trackId: trackId }, 10000, function (err, canonical) {
        if (err) { self._setAuthFromError(err); if (cb) { cb(err); } return; }
        if (canonical) { self._applyCanonicalState(canonical); }
        self._syncRemoteState();
        if (cb) { cb(null, canonical); }
      });
      return;
    }
    if (options && options.shuffleState !== undefined && options.shuffleState !== null) {
      this.local.state.shuffle = !!options.shuffleState;
    }
    this.local.playTrack(trackId, queueIds, cb);
  };
  MiniHubMediaCarOSService.prototype.getQueue = function (cb) { this.local.getQueue(cb); };
  MiniHubMediaCarOSService.prototype.toggleShuffle = function (cb) {
    var self = this;
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/player/shuffle'), {}, 7000, function (err, data) {
      if (err) { self._setAuthFromError(err); }
      if (!err && data) { self._applyCanonicalState(data); }
      if (cb) { cb(err, data); }
    });
  };
  MiniHubMediaCarOSService.prototype.cycleRepeat = function (cb) {
    var self = this;
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/player/repeat'), {}, 7000, function (err, data) {
      if (err) { self._setAuthFromError(err); }
      if (!err && data) { self._applyCanonicalState(data); }
      if (cb) { cb(err, data); }
    });
  };

  MiniHubMediaCarOSService.prototype._loadLibraryPages = function (offset, items, cb) {
    var self = this;
    var limit = 100;
    this._request('/api/v1/library?limit=' + limit + '&offset=' + offset, function (err, data) {
      if (err) { cb(err); return; }
      var page = mhArray(data);
      var i;
      for (i = 0; i < page.length; i++) { items.push(page[i]); }
      var total = Number(data && data.count !== undefined ? data.count : items.length);
      if (items.length < total && page.length > 0) {
        self._loadLibraryPages(items.length, items, cb);
        return;
      }
      cb(null, { tracks: items });
    });
  };

  MiniHubMediaCarOSService.prototype.getLibrary = function (cb) {
    var self = this;
    this._loadLibraryPages(0, [], function (err, data) {
      if (!err) {
        var library = normalizeMiniHubLibrary(data, self.baseUrl);
        self._applyLibrary(library, true);
        self._saveCache(library);
        cb(null, library);
        return;
      }
      if (!self.library) { self._loadCache(); }
      if (self.library) { cb(null, self.library); return; }
      cb(err || new Error('Biblioteca MiniHub indisponível'));
    });
  };

  MiniHubMediaCarOSService.prototype.getDevices = function (cb) {
    var self = this;
    this._request('/api/status', function (err, status) {
      var list = [
        { id: 'dev_ipad', name: 'iPad mini', kind: 'tablet', role: 'Player local do Web MiniHub', status: 'online', detail: 'Safari · áudio neste dispositivo' },
        { id: 'dev_a23', name: 'Galaxy A23', kind: 'phone', role: 'MiniHub · biblioteca e streaming', status: err ? 'offline' : 'online', detail: err ? 'Servidor não respondeu' : ('MiniHub' + (status && status.version ? ' · ' + status.version : '')) }
      ];
      cb(null, list);
    });
  };

  MiniHubMediaCarOSService.prototype.getFiles = function (path, cb) {
    cb(new Error('Arquivos do MiniHub serão conectados em uma etapa própria'));
  };
  MiniHubMediaCarOSService.prototype.getRoutes = function (cb) { later(function () { cb(null, []); }); };
  MiniHubMediaCarOSService.prototype.getMessages = function (cb) { later(function () { cb(null, []); }); };
  MiniHubMediaCarOSService.prototype.getLocation = function (cb) { if (window.MiniHubIOS && window.MiniHubIOS.available) { window.MiniHubIOS.getLocation(cb); return; } this._request('/api/v1/location/state', cb); };
  MiniHubMediaCarOSService.prototype.getNavigationState = function (cb) { this._request('/api/v1/navigation/state', cb); };
  MiniHubMediaCarOSService.prototype.startLocation = function (cb) {
    if (window.MiniHubIOS && window.MiniHubIOS.available) { window.MiniHubIOS.startLocation(cb); return; }
    var self = this;
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/location/start'), {}, 7000, function (err, data) {
      if (err) { self._setAuthFromError(err); }
      if (cb) { cb(err, data); }
    });
  };
  MiniHubMediaCarOSService.prototype.stopLocation = function (cb) {
    if (window.MiniHubIOS && window.MiniHubIOS.available) { window.MiniHubIOS.stopLocation(cb); return; }
    var self = this;
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/location/stop'), {}, 7000, function (err, data) {
      if (err) { self._setAuthFromError(err); }
      if (cb) { cb(err, data); }
    });
  };
  MiniHubMediaCarOSService.prototype.setLocationMode = function (mode, cb) {
    var self = this;
    WC.http('POST', mhJoin(this.baseUrl, '/api/v1/location/mode'), { mode: mode || 'NORMAL' }, 7000, function (err, data) {
      if (err) { self._setAuthFromError(err); }
      if (cb) { cb(err, data); }
    });
  };
  MiniHubMediaCarOSService.prototype.ping = function (cb) { this._request('/api/v1/health', cb); };
  MiniHubMediaCarOSService.prototype.clearLibraryCache = function () {
    WC.storage.remove(this.cacheKey);
    this.cacheSavedAt = 0;
  };

  /* ====================================================================== */
  /* HttpCarOSService — generic client for the Web MiniHub JSON API.           */
  /* State is pulled by polling: the most reliable option on iOS 9.         */

  function HttpCarOSService(options) {
    BaseService.call(this);
    this.id = options.id;
    this.label = options.label;
    this.baseUrl = String(options.baseUrl || '').replace(/\/+$/, '');
    this.pollMs = options.pollMs || 2000;
    this.timer = null;
  }
  inherit(HttpCarOSService, BaseService);

  HttpCarOSService.prototype.request = function (method, path, body, cb) {
    var self = this;
    cb = cb || noop;
    if (!this.baseUrl) {
      later(function () { self._setConnected(false); cb(new Error('Endereço não configurado')); });
      return;
    }
    WC.http(method, this.baseUrl + path, body, 6000, function (err, data) {
      self._setConnected(!err);
      cb(err, data);
    });
  };

  /* Commands answer with the new player state; broadcast it immediately. */
  HttpCarOSService.prototype._command = function (path, body, cb) {
    var self = this;
    this.request('POST', path, body || {}, function (err, state) {
      if (!err && state) { self.emitter.emit('state', state); }
      if (cb) { cb(err, state); }
    });
  };

  HttpCarOSService.prototype.start = function () {
    var self = this;
    if (this.timer) { return; }
    function poll() {
      self.getPlayerState(function (err, state) {
        if (!err && state) { self.emitter.emit('state', state); }
      });
    }
    poll();
    this.timer = setInterval(poll, this.pollMs);
  };
  HttpCarOSService.prototype.stop = function () {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
  };

  HttpCarOSService.prototype.getPlayerState = function (cb) { this.request('GET', '/api/v1/player/state', null, cb); };
  HttpCarOSService.prototype.play = function (cb) { this._command('/api/v1/player/play', null, cb); };
  HttpCarOSService.prototype.pause = function (cb) { this._command('/api/v1/player/pause', null, cb); };
  HttpCarOSService.prototype.next = function (cb) { this._command('/api/v1/player/next', null, cb); };
  HttpCarOSService.prototype.previous = function (cb) { this._command('/api/v1/player/previous', null, cb); };
  HttpCarOSService.prototype.seek = function (seconds, cb) { this._command('/api/v1/player/seek', { position: seconds }, cb); };
  HttpCarOSService.prototype.setVolume = function (volume, cb) { this._command('/api/v1/player/volume', { volume: volume }, cb); };
  HttpCarOSService.prototype.toggleShuffle = function (cb) { this._command('/api/v1/player/shuffle', {}, cb); };
  HttpCarOSService.prototype.cycleRepeat = function (cb) { this._command('/api/v1/player/repeat', {}, cb); };
  HttpCarOSService.prototype.playTrack = function (trackId, queueIds, cb, options) {
    if (options && options.fromAllTracks) {
      this._command('/api/v1/library/play', { trackId: trackId }, cb);
      return;
    }
    var body = { trackId: trackId, queue: queueIds || null };
    if (options && options.shuffleState !== undefined && options.shuffleState !== null) { body.shuffleState = !!options.shuffleState; }
    this._command('/api/v1/player/queue', body, cb);
  };
  HttpCarOSService.prototype.getQueue = function (cb) { this.request('GET', '/api/v1/player/queue', null, cb); };
  HttpCarOSService.prototype.getLibrary = function (cb) { this.request('GET', '/api/v1/library', null, cb); };
  HttpCarOSService.prototype.getDevices = function (cb) { this.request('GET', '/api/v1/devices', null, cb); };
  HttpCarOSService.prototype.getRoutes = function (cb) { this.request('GET', '/api/v1/navigation/routes', null, cb); };
  HttpCarOSService.prototype.getNavigationState = function (cb) { this.request('GET', '/api/v1/navigation/state', null, cb); };
  HttpCarOSService.prototype.getMessages = function (cb) { this.request('GET', '/api/v1/messages', null, cb); };
  HttpCarOSService.prototype.getLocation = function (cb) { this.request('GET', '/api/v1/location/state', null, cb); };
  HttpCarOSService.prototype.startLocation = function (cb) { this.request('POST', '/api/v1/location/start', {}, cb); };
  HttpCarOSService.prototype.stopLocation = function (cb) { this.request('POST', '/api/v1/location/stop', {}, cb); };
  HttpCarOSService.prototype.setLocationMode = function (mode, cb) { this.request('POST', '/api/v1/location/mode', { mode: mode || 'NORMAL' }, cb); };
  HttpCarOSService.prototype.getFiles = function (path, cb) {
    this.request('GET', '/api/v1/files?path=' + encodeURIComponent(path), null, cb);
  };
  HttpCarOSService.prototype.ping = function (cb) { this.request('GET', '/api/v1/health', null, cb); };

  function CloudCarOSService(baseUrl) {
    HttpCarOSService.call(this, { id: 'cloud', label: 'Nuvem', baseUrl: baseUrl, pollMs: 2500 });
  }
  inherit(CloudCarOSService, HttpCarOSService);

  /* Note: if Web MiniHub is served over HTTPS, Safari blocks http:// calls to a
     MiniHub on the LAN (mixed content). Local mode therefore expects Web MiniHub
     to be opened from the MiniHub itself, or MiniHub to serve HTTPS. */
  function MiniHubCarOSService(baseUrl) {
    HttpCarOSService.call(this, { id: 'minihub', label: 'MiniHub', baseUrl: baseUrl, pollMs: 1500 });
  }
  inherit(MiniHubCarOSService, HttpCarOSService);

  /* ====================================================================== */
  /* HybridCarOSService — picks the first reachable backend:                */
  /* MiniHub (local) → Cloud → Demo. Re-checks periodically.               */

  function HybridCarOSService(candidates, fallback) {
    BaseService.call(this);
    this.id = 'hybrid';
    this.label = 'Híbrido';
    this.candidates = candidates;
    this.fallback = fallback;
    this.active = null;
    this.timer = null;
    this.started = false;
    var self = this;
    this._forwardState = function (s) { self.emitter.emit('state', s); };
    this._forwardStatus = function () { self.emitter.emit('status', self.getInfo()); };
  }
  inherit(HybridCarOSService, BaseService);

  HybridCarOSService.prototype.getInfo = function () {
    var a = this.active;
    return {
      id: 'hybrid',
      label: 'Híbrido · ' + (a ? a.label : '…'),
      connected: a ? a.connected : false,
      activeId: a ? a.id : null
    };
  };

  HybridCarOSService.prototype._use = function (service) {
    if (this.active === service) { return; }
    if (this.active) {
      this.active.stop();
      this.active.off('state', this._forwardState);
      this.active.off('status', this._forwardStatus);
    }
    this.active = service;
    service.on('state', this._forwardState);
    service.on('status', this._forwardStatus);
    if (this.started) { service.start(); }
    this.emitter.emit('status', this.getInfo());
    this.emitter.emit('switched', this.getInfo());
  };

  HybridCarOSService.prototype.probe = function (cb) {
    var self = this;
    var list = this.candidates;
    var i = 0;
    function tryNext() {
      if (i >= list.length) { self._use(self.fallback); if (cb) { cb(); } return; }
      var candidate = list[i++];
      candidate.ping(function (err) {
        if (!err) { self._use(candidate); if (cb) { cb(); } return; }
        tryNext();
      });
    }
    tryNext();
  };

  HybridCarOSService.prototype.start = function () {
    var self = this;
    this.started = true;
    if (!this.active) { this._use(this.fallback); }
    this.active.start();
    this.probe();
    this.timer = setInterval(function () { self.probe(); }, 30000);
  };
  HybridCarOSService.prototype.stop = function () {
    this.started = false;
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    if (this.active) { this.active.stop(); }
  };

  for (var m = 0; m < METHODS.length; m++) {
    (function (name) {
      HybridCarOSService.prototype[name] = function () {
        var target = this.active || this.fallback;
        return target[name].apply(target, arguments);
      };
    })(METHODS[m]);
  }

  /* ====================================================================== */

  /* iOS local library: real files from the app Documents folder. */
  function IOSLocalCarOSService() {
    this.id = 'ios-local'; this.label = 'Biblioteca local do iPad'; this.connected = true;
    this.emitter = new Emitter(); this.library = {artists:[], albums:[], tracks:[], playlists:[]};
    this.local = new MockCarOSService({library:this.library, devices:[], routes:[], messages:[], files:{'/':[]}, initialPlayerState:{currentTrack:null,position:0,playing:false,volume:0.8,queue:[]}}, {label:'iPad'});
  }
  IOSLocalCarOSService.prototype.on=function(n,f){this.emitter.on(n,f);};
  IOSLocalCarOSService.prototype.start=function(){ var self=this; if(!window.MiniHubIOS || !window.MiniHubIOS.available){self.emitter.emit('status');return;} window.MiniHubIOS.getLocalLibrary(function(err,data){
    var raw=(!err&&data&&data.tracks)||[], artists=[{id:'ios_artist',name:'No iPad'}], albums=[{id:'ios_album',title:'Pasta local',artistId:'ios_artist'}], tracks=[], ids=[], i,r;
    for(i=0;i<raw.length;i++){r=raw[i]; tracks.push({id:r.id,title:r.title||'Faixa',artistId:'ios_artist',albumId:'ios_album',duration:Number(r.duration||0),src:r.src});ids.push(r.id);}
    self.library={artists:artists,albums:albums,tracks:tracks,playlists:tracks.length?[{id:'ios_all',name:'Todas as músicas',trackIds:ids}]:[]};
    self.local.fixtures.library=self.library; self.local.trackIndex={}; for(i=0;i<tracks.length;i++){self.local.trackIndex[tracks[i].id]=tracks[i];}
    self.local.state={currentTrack:ids.length?ids[0]:null,position:0,playing:false,volume:0.8,queue:ids.slice()}; self.local.start(); self.emitter.emit('status'); self.emitter.emit('state',self.local.state);
  });};
  IOSLocalCarOSService.prototype.stop=function(){this.local.stop();};
  IOSLocalCarOSService.prototype.getInfo=function(){return {id:this.id,label:this.label,connected:true,libraryCount:this.library.tracks.length,local:true};};
  IOSLocalCarOSService.prototype.getLibrary=function(cb){cb(null,this.library);};
  IOSLocalCarOSService.prototype.getPlayerState=function(cb){this.local.getPlayerState(cb);};
  ['play','pause','next','previous','seek','setVolume','playTrack','getQueue','getDevices','getFiles','getRoutes','getMessages','getLocation','startLocation','stopLocation','pair','reset'].forEach(function(m){IOSLocalCarOSService.prototype[m]=function(){return this.local[m].apply(this.local,arguments);};});

  WC.services = {
    METHODS: METHODS,
    MockCarOSService: MockCarOSService,
    HttpCarOSService: HttpCarOSService,
    CloudCarOSService: CloudCarOSService,
    MiniHubCarOSService: MiniHubCarOSService,
    MiniHubMediaCarOSService: MiniHubMediaCarOSService,
    IOSLocalCarOSService: IOSLocalCarOSService,
    HybridCarOSService: HybridCarOSService,

    /* Builds the service for the "Conexão" setting. */
    create: function (settings, fixtures) {
      var mode = settings.serviceMode;
      if (window.MiniHubIOS && window.MiniHubIOS.available && (!settings.minihubUrl || mode === 'ios_local')) { return new IOSLocalCarOSService(); }
      if (mode === 'cloud') { return new CloudCarOSService(settings.cloudUrl); }
      if (mode === 'minihub') { return new MiniHubCarOSService(settings.minihubUrl); }
      if (mode === 'minihub_media') { return new MiniHubMediaCarOSService(settings.minihubUrl, fixtures); }
      if (mode === 'hybrid') {
        var candidates = [];
        if (settings.minihubUrl) { candidates.push(new MiniHubCarOSService(settings.minihubUrl)); }
        if (settings.cloudUrl) { candidates.push(new CloudCarOSService(settings.cloudUrl)); }
        return new HybridCarOSService(candidates, new MockCarOSService(fixtures));
      }
      return new MockCarOSService(fixtures);
    }
  };
})(window);
