/*
 * WC.audio — one shared <audio> element for local playback on the iPad.
 * ES5 ONLY (Safari 9 / iOS 9).
 *
 * iOS rules this works around:
 *  - Sound may only START inside a user gesture (our tap fires on touchend,
 *    which iOS 9 accepts). After the first play() the same element stays
 *    unlocked, so later src changes (next track, end of track) keep playing.
 *    That is why there is exactly ONE element, reused for every track.
 *  - play() returns undefined on iOS 9 (a Promise on newer browsers).
 *  - currentTime cannot be set before metadata arrives: seeks are deferred.
 *  - element.volume is ignored on iOS (hardware buttons only).
 *
 * Events: 'error' {code, message}, 'ended', 'interrupted' (paused by the
 * system: phone call, Control Center), 'resumed' (played from the lock screen).
 */
(function (window, document) {
  'use strict';

  var WC = window.WC;

  var ERRORS = {
    1: 'MEDIA_ERR_ABORTED (carregamento interrompido)',
    2: 'MEDIA_ERR_NETWORK (erro de rede)',
    3: 'MEDIA_ERR_DECODE (arquivo de áudio corrompido)',
    4: 'MEDIA_ERR_SRC_NOT_SUPPORTED (formato ou endereço não suportado)'
  };

  function AudioEngine() {
    this.emitter = new WC.Emitter();
    this.el = null;
    this.src = null;
    this.wantPlaying = false;
    this.pendingSeek = null;
    this.failed = false;
    this.lastError = null;
    this.log = [];
  }

  AudioEngine.prototype.supported = function () {
    try {
      var a = document.createElement('audio');
      return !!(a.canPlayType && a.canPlayType('audio/mpeg').replace(/no/, ''));
    } catch (e) {
      return false;
    }
  };

  AudioEngine.prototype._note = function (text) {
    var d = new Date();
    this.log.unshift(WC.util.pad2(d.getHours()) + ':' + WC.util.pad2(d.getMinutes()) + ':' + WC.util.pad2(d.getSeconds()) + ' ' + text);
    if (this.log.length > 30) { this.log.length = 30; }
  };

  AudioEngine.prototype._element = function () {
    if (this.el) { return this.el; }
    var self = this;
    var a = this.el = document.createElement('audio');
    a.preload = 'auto';

    a.addEventListener('loadedmetadata', function () {
      self._note('metadados (' + Math.round(a.duration) + ' s)');
      self._applySeek();
      self.emitter.emit('loadedmetadata', { duration: a.duration });
    }, false);
    a.addEventListener('canplay', function () {
      self._applySeek();
      self.emitter.emit('canplay');
    }, false);
    a.addEventListener('playing', function () {
      self._note('tocando');
      self.emitter.emit('playing');
    }, false);
    a.addEventListener('timeupdate', function () {
      self.emitter.emit('timeupdate', {
        currentTime: a.currentTime,
        duration: a.duration
      });
    }, false);
    a.addEventListener('durationchange', function () {
      self.emitter.emit('durationchange', {
        duration: a.duration
      });
    }, false);
    a.addEventListener('waiting', function () { self._note('carregando…'); }, false);
    a.addEventListener('stalled', function () { self._note('rede travou'); }, false);
    a.addEventListener('pause', function () {
      if (self.wantPlaying && !a.ended) {
        self.wantPlaying = false;
        self._note('pausado pelo sistema');
        self.emitter.emit('interrupted');
      }
      self.emitter.emit('pause');
    }, false);
    a.addEventListener('play', function () {
      if (!self.wantPlaying) {
        self.wantPlaying = true;
        self._note('retomado pelo sistema');
        self.emitter.emit('resumed');
      }
    }, false);
    a.addEventListener('ended', function () {
      self.wantPlaying = false;
      self._note('fim da faixa');
      self.emitter.emit('ended');
    }, false);
    a.addEventListener('error', function () {
      var code = a.error ? a.error.code : 0;
      self.failed = true;
      self.wantPlaying = false;
      var msg = ERRORS[code] || ('erro ' + code);
      self._note('erro ' + code + ': ' + msg);
      self.lastError = { code: code, message: msg };
      self.emitter.emit('error', { code: code, message: msg });
    }, false);
    return a;
  };

  AudioEngine.prototype._applySeek = function () {
    if (this.pendingSeek === null || !this.el) { return; }
    try {
      this.el.currentTime = this.pendingSeek;
      this.pendingSeek = null;
    } catch (e) { /* not seekable yet; retried on canplay */ }
  };

  /* Points the element at a file. Returns true when the file changed
     (a failed file is reopened, so a later tap retries it). */
  AudioEngine.prototype.load = function (src) {
    var a = this._element();
    if (this.src === src && !this.failed) { return false; }
    this.src = src;
    this.failed = false;
    this.pendingSeek = null;
    this._note('abrindo ' + src);
    a.src = src;
    a.load();
    return true;
  };

  /* Must be called synchronously from a tap for the first sound on iOS. */
  AudioEngine.prototype.play = function () {
    var self = this;
    var a = this._element();
    if (!this.src) { return; }
    this.wantPlaying = true;
    var result;
    try {
      result = a.play();
    } catch (e) {
      this.wantPlaying = false;
      this.emitter.emit('error', { code: 0, message: e.message });
      return;
    }
    if (result && typeof result.then === 'function') {
      result.then(null, function (err) {
        if (!self.wantPlaying) { return; }
        self.wantPlaying = false;
        self._note('bloqueado: ' + (err && err.name));
        self.emitter.emit('interrupted');
      });
    }
  };

  AudioEngine.prototype.pause = function () {
    this.wantPlaying = false;
    if (this.el) {
      try { this.el.pause(); } catch (e) { /* ignore */ }
    }
  };

  AudioEngine.prototype.seek = function (seconds) {
    this.pendingSeek = Math.max(0, seconds);
    if (this.el && this.el.readyState >= 1) { this._applySeek(); }
  };

  AudioEngine.prototype.setVolume = function (volume) {
    if (!this.el) { return; }
    try { this.el.volume = Math.max(0, Math.min(1, volume)); } catch (e) { /* ignore */ }
  };

  /* Current playhead in seconds, or null while unknown (loading / failed). */
  AudioEngine.prototype.position = function () {
    var a = this.el;
    if (!a || this.failed || a.readyState < 1) { return null; }
    if (this.pendingSeek !== null) { return this.pendingSeek; }
    return a.currentTime;
  };

  /* Duration in seconds, or null when unknown. */
  AudioEngine.prototype.duration = function () {
    var a = this.el;
    return (a && !isNaN(a.duration) && a.duration > 0) ? a.duration : null;
  };

  /* True when sound is actually coming out (not just requested). */
  AudioEngine.prototype.isSounding = function () {
    var a = this.el;
    return !!(a && !a.paused && !a.ended && !this.failed && a.readyState >= 3);
  };

  AudioEngine.prototype.on = function (name, fn) { this.emitter.on(name, fn); return this; };
  AudioEngine.prototype.off = function (name, fn) { this.emitter.off(name, fn); return this; };

  WC.AudioEngine = AudioEngine;
  WC.audio = new AudioEngine();
})(window, document);
