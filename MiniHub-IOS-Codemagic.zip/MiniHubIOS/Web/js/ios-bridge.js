/* MiniHub iOS bridge — ES5 only, compatible with iOS 9 WebKit. */
(function (window) {
  'use strict';
  var bridge = window.MiniHubIOS = window.MiniHubIOS || {};
  var callbacks = {};
  var seq = 1;
  bridge.available = !!(window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.minihub);
  bridge.call = function (action, payload, callback) {
    if (!bridge.available) { if (callback) { callback(new Error('Ponte iOS indisponível')); } return; }
    var id = 'ios_' + (seq++);
    if (callback) { callbacks[id] = callback; }
    window.webkit.messageHandlers.minihub.postMessage({ id: id, action: action, payload: payload || {} });
  };
  bridge.receive = function (id, error, data) {
    var cb = callbacks[id];
    if (!cb) { return; }
    delete callbacks[id];
    cb(error ? new Error(error) : null, data || null);
  };
  bridge.getLocation = function (cb) { bridge.call('getLocation', {}, cb); };
  bridge.startLocation = function (cb) { bridge.call('startLocation', {}, cb); };
  bridge.stopLocation = function (cb) { bridge.call('stopLocation', {}, cb); };
  bridge.discoverHost = function (cb) { bridge.call('discoverHost', {}, cb); };
  bridge.getLocalLibrary = function (cb) { bridge.call('getLocalLibrary', {}, cb); };
})(window);
