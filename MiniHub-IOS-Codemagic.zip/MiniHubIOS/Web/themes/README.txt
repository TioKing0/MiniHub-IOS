Web MiniHub Theme Pack
===================
Copie TEMPLATE.json, altere id/nome/cores e salve como .json.
No Web MiniHub: Ajustes > Aparência > Importar skin.

Regras:
- arquivo JSON de até 32 KB;
- cores no formato #RRGGBB;
- o pacote contém apenas dados, nunca JavaScript ou CSS executável;
- temas importados ficam no armazenamento local do navegador/dispositivo.

Campos de palette:
bg          fundo principal
surface     cartões/painéis
surface2    botões/superfícies secundárias
border      bordas
text        texto principal
muted       texto secundário
soft        texto suave
accent      cor de destaque
accentText  texto sobre a cor de destaque

Web MiniHub Local v0.7.0: skins podem declarar "layout": "classic" ou "dashboard-grid".
A skin interna "MiniHub Classic" usa dashboard-grid em TODO o shell: Home, Player, Arquivos, Galeria, Contatos, Navegação, Mensagens, Dispositivos e Ajustes.
Os atalhos da Home são configuração do usuário e podem ser adicionados, removidos e reordenados sem editar a skin.
Para segurança e compatibilidade, skins importadas continuam sendo JSON de dados, nunca CSS/JS executável.
