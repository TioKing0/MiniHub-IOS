#import "ViewController.h"
@interface ViewController ()
@property(nonatomic,strong) WKWebView *webView;
@property(nonatomic,strong) CLLocationManager *locationManager;
@property(nonatomic,strong) CLLocation *lastLocation;
@property(nonatomic,assign) BOOL tracking;
@property(nonatomic,strong) NSNetServiceBrowser *browser;
@property(nonatomic,strong) NSNetService *resolvingService;
@property(nonatomic,copy) NSString *pendingDiscoveryId;
@end
@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor blackColor];
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    [config.userContentController addScriptMessageHandler:self name:@"minihub"];
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
    self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.webView.scrollView.bounces = NO;
    [self.view addSubview:self.webView];
    self.locationManager = [[CLLocationManager alloc] init];
    self.locationManager.delegate = self;
    self.locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    self.browser = [[NSNetServiceBrowser alloc] init]; self.browser.delegate = self;
    NSString *path = [[NSBundle mainBundle] pathForResource:@"index" ofType:@"html" inDirectory:@"Web"];
    NSURL *url = [NSURL fileURLWithPath:path];
    [self.webView loadFileURL:url allowingReadAccessToURL:[NSURL fileURLWithPath:NSHomeDirectory()]];
}
- (void)dealloc { [self.webView.configuration.userContentController removeScriptMessageHandlerForName:@"minihub"]; }
- (void)reply:(NSString *)rid error:(NSString *)error data:(NSDictionary *)data {
    NSData *json = [NSJSONSerialization dataWithJSONObject:(data ?: @{}) options:0 error:nil];
    NSString *payload = [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding];
    NSString *safeError = error ? [NSString stringWithFormat:@"'%@'", [error stringByReplacingOccurrencesOfString:@"'" withString:@"\\'"]] : @"null";
    NSString *js = [NSString stringWithFormat:@"window.MiniHubIOS.receive('%@', %@, %@);", rid, safeError, payload ?: @"{}"];
    [self.webView evaluateJavaScript:js completionHandler:nil];
}
- (NSDictionary *)locationState {
    CLLocation *l = self.lastLocation;
    if (!l) return @{ @"supported":@YES, @"tracking":@(self.tracking), @"requested":@(self.tracking), @"locationEnabled":@([CLLocationManager locationServicesEnabled]), @"hasFix":@NO, @"message":@"Aguardando posição do iPad" };
    return @{ @"supported":@YES, @"tracking":@(self.tracking), @"requested":@(self.tracking), @"locationEnabled":@YES, @"hasFix":@YES, @"latitude":@(l.coordinate.latitude), @"longitude":@(l.coordinate.longitude), @"accuracyMeters":@(l.horizontalAccuracy), @"speedMps":@(MAX(0,l.speed)), @"courseDegrees":@(MAX(0,l.course)), @"altitudeMeters":@(l.altitude), @"timestampMs":@([l.timestamp timeIntervalSince1970]*1000.0), @"source":@"ipad_corelocation" };
}

- (NSDictionary *)localLibrary {
    NSString *documents = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *exts = @[@"m4a", @"mp3", @"aac", @"wav", @"caf", @"aif", @"aiff"];
    NSMutableArray *tracks = [NSMutableArray array];
    NSDirectoryEnumerator *en = [fm enumeratorAtURL:[NSURL fileURLWithPath:documents] includingPropertiesForKeys:@[NSURLIsRegularFileKey] options:NSDirectoryEnumerationSkipsHiddenFiles errorHandler:nil];
    NSURL *u = nil; NSInteger idx = 0;
    while ((u = [en nextObject])) {
        if (![exts containsObject:[[u pathExtension] lowercaseString]]) continue;
        NSNumber *regular = nil; [u getResourceValue:&regular forKey:NSURLIsRegularFileKey error:nil];
        if (![regular boolValue]) continue;
        idx++;
        NSString *title = [[[u lastPathComponent] stringByDeletingPathExtension] stringByReplacingOccurrencesOfString:@"_" withString:@" "];
        [tracks addObject:@{ @"id":[NSString stringWithFormat:@"ios_local_%ld",(long)idx], @"title":title ?: @"Faixa", @"artist":@"No iPad", @"album":@"Pasta local", @"duration":@0, @"src":[u absoluteString] ?: @"", @"local":@YES }];
    }
    return @{ @"source":@"ipad_documents", @"path":documents ?: @"", @"tracks":tracks };
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    NSDictionary *m = [message.body isKindOfClass:[NSDictionary class]] ? message.body : @{}; NSString *rid=m[@"id"] ?: @""; NSString *action=m[@"action"] ?: @"";
    if ([action isEqualToString:@"getLocalLibrary"]) { [self reply:rid error:nil data:[self localLibrary]]; return; }
    if ([action isEqualToString:@"getLocation"]) { [self reply:rid error:nil data:[self locationState]]; return; }
    if ([action isEqualToString:@"startLocation"]) { if ([self.locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) [self.locationManager requestWhenInUseAuthorization]; self.tracking=YES; [self.locationManager startUpdatingLocation]; [self reply:rid error:nil data:@{@"supported":@YES,@"started":@YES}]; return; }
    if ([action isEqualToString:@"stopLocation"]) { self.tracking=NO; [self.locationManager stopUpdatingLocation]; [self reply:rid error:nil data:@{@"supported":@YES,@"started":@NO}]; return; }
    if ([action isEqualToString:@"discoverHost"]) { self.pendingDiscoveryId=rid; [self.browser stop]; [self.browser searchForServicesOfType:@"_http._tcp." inDomain:@"local."]; return; }
    [self reply:rid error:@"Ação iOS desconhecida" data:nil];
}
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations { self.lastLocation=[locations lastObject]; }
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error { }
- (void)netServiceBrowser:(NSNetServiceBrowser *)browser didFindService:(NSNetService *)service moreComing:(BOOL)moreComing {
    if ([[service.name lowercaseString] rangeOfString:@"minihub"].location == NSNotFound) return;
    [browser stop]; self.resolvingService=service; service.delegate=self; [service resolveWithTimeout:5.0];
}
- (void)netServiceDidResolveAddress:(NSNetService *)sender {
    NSString *host=sender.hostName ?: @"webminihub.local"; NSInteger port=sender.port; NSString *url=[NSString stringWithFormat:@"http://%@:%ld",host,(long)port];
    if (self.pendingDiscoveryId) [self reply:self.pendingDiscoveryId error:nil data:@{@"found":@YES,@"name":sender.name ?: @"MiniHub",@"host":host,@"port":@(port),@"baseUrl":url}]; self.pendingDiscoveryId=nil;
}
- (void)netService:(NSNetService *)sender didNotResolve:(NSDictionary *)errorDict { if(self.pendingDiscoveryId)[self reply:self.pendingDiscoveryId error:@"MiniHub encontrado, mas não foi possível resolver o endereço" data:nil]; self.pendingDiscoveryId=nil; }
@end
