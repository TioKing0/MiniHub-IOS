# MiniHub iOS 9

Cliente iOS do MiniHub para iPad mini 1 (iOS 9 / ARMv7).

## Codemagic

O repositório contém `codemagic.yaml`. O workflow `minihub-ios9-unsigned` compila sem assinatura e empacota `MiniHub.ipa`, pensado para dispositivo com jailbreak/AppSync.

> Atenção: ARMv7/iOS 9 exige um Xcode antigo que ainda suporte ARMv7. O projeto está configurado corretamente para o alvo, mas o pool atual do Codemagic pode não oferecer esse toolchain por padrão. Se o build falhar por arquitetura/SDK, será necessário selecionar/solicitar uma imagem antiga compatível.

## Biblioteca local

Sem Android conectado, o app usa somente músicas reais em `Documents` do próprio MiniHub no iPad. Não existe modo demo.

Formatos reconhecidos: M4A, MP3, AAC, WAV, CAF, AIF e AIFF.
