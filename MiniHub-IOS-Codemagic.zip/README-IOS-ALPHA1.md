# MiniHub iOS Alpha 1.1 — biblioteca local real

- Sem modo demo e sem músicas fictícias.
- Sem Android, lê arquivos reais da pasta Documents do MiniHub no iPad.
- Formatos indexados: M4A, MP3, AAC, WAV, CAF, AIF/AIFF.
- UIFileSharingEnabled permite copiar músicas para a pasta do app via compartilhamento de arquivos.
- Core Location continua usando o GPS do próprio iPad.
- Bonjour/mDNS continua disponível para localizar o MiniHub Android.
- Quando o Android estiver conectado, a arquitetura permite usar sua biblioteca/streaming como fonte remota.

Observação: iOS mantém sandbox por aplicativo; portanto “pasta local” significa Documents do MiniHub, não varredura arbitrária de todo o armazenamento do iPad.
